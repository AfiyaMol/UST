package reqresapi;


import com.intuit.karate.junit5.Karate;

public class ReqresRunner {

	@Karate.Test
	public Karate runTest() {
		
	//	return Karate.run("src/test/java/reqresapi/sReqresapi.feature");
		return Karate.run("Reqresapi.feature").tags("tag1").relativeTo(getClass());
		
	}
}
