package jsonplaceholder;

import com.intuit.karate.junit5.Karate;

public class JsonRunner {
	@Karate.Test
	public Karate runTest() {

//		return Karate.run("src/test/java/reqresapi/sReqresapi.feature");
//		return Karate.run("json.feature").relativeTo(getClass());
//		return Karate.run("json.feature").tags("@smoke , @regression").relativeTo(getClass());
		return Karate.run("json.feature").tags("@schemaValidation").relativeTo(getClass());
//		return Karate.run("json.feature").tags("@regression3").relativeTo(getClass());
	}
}
