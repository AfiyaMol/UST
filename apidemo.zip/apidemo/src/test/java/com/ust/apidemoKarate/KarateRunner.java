package com.ust.apidemoKarate;

import com.intuit.karate.junit5.Karate;
public class KarateRunner {

		@Karate.Test
		public Karate runTest() {
			return Karate.run("karate.feature").tags("tag").relativeTo(getClass());
			
		}

}
