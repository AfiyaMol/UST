package endpoints;

public class Routes {

	public static String baseUri="https://reqres.in";
	public static String get_list="/api/users?";
	public static String get_single="/api/users/{id}";
	public static String post_user="/api/users";
	public static String put="/api/users/{id}";
	public static String patch="/api/users/{id}";
	public static String delete="/api/users/{id}";
	public static String baseUrii="https://reqres.in/api/users/2";
}
