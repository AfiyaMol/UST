package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Browser {
	
	public WebDriver driver;
	public WebDriver launch_Chrome() {
		driver = new ChromeDriver();
		return driver;
		
	}
	public WebDriver launch_Edge() {
		driver = new EdgeDriver();
		return driver;
	}

}
