package assignment;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Amazon {
  
	  
	  WebDriver driver ;
		 @BeforeClass
		  public void beforeClass() {
			  driver =new ChromeDriver();
		  }
		@BeforeMethod
		  public void beforeMethod() {
			driver.get("https://www.amazon.in/");
		  }
	 
	  @Test
	  public void validateResult() throws InterruptedException
	  {
		 driver.findElement(By.linkText("Today's Deals")).click();
		 driver.findElement(By.linkText("Clearance")).click();
		 //selecting watches
		driver.findElements(By.className("a-list-item")).get(3).click();
		//ticking the checkbox
		//driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"p_90/6741118031\"]/span//i")).click();
		Thread.sleep(2000);
//		Thread.sleep(2000);
		String str=driver.findElement(By.className("s-no-outline")).getText();
		
		//Checking actual and expected text
		assertEquals(str,"Results");
		System.out.println(str);
		boolean act=driver.findElements(By.partialLinkText("Watch")).get(0).isDisplayed();
		//Checking if 1st item contain 'watch' text
		assertEquals(act,true);
		driver.quit();  
	  }

  
}
