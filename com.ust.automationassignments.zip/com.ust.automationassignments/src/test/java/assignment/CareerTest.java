package assignment;

import static org.testng.Assert.assertEquals;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.locators.RelativeLocator;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import utils.ScreenshotUst;

public class CareerTest {
	WebDriver driver;
			
	@Test
	public void verify() throws InterruptedException {
		driver=new ChromeDriver();
		driver.get("https://www.ust.com/en/careers");
		Thread.sleep(10000);
		driver.findElement(By.id("onetrust-accept-btn-handler")).click();
		Thread.sleep(6000);
		driver.findElement(By.linkText("India Careers")).click();
		Thread.sleep(6000);
		//ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
//		driver.switchTo().window(tabs.get(1));
//		Thread.sleep(5000);
//		driver.findElement(By.cssSelector("#search-panel > div > div.search-box.MB20 > form > div > div.input-group.search-div > input")).sendKeys("test automation");
		
		Set<String> windowHandles = driver.getWindowHandles();
		for (String handle : windowHandles)
		{
		driver.switchTo().window(handle);
		}
		
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"search-panel\"]/div/div[1]/form/div/div[1]/input")));
		// to search test automation
		WebElement job= driver.findElement(By.xpath("//*[@id=\"search-panel\"]/div/div[1]/form/div/div[1]/input"));
		job.sendKeys("test automation");
		//to search thiruvananthapuram
		 WebElement location = driver.findElement(RelativeLocator.with(By.className("location-select-text")).toRightOf(job));
		  //Thread.sleep(2000);
		 location.click();
		  driver.findElement(By.linkText("Thiruvananthapuram (103)")).click();
		  // to get 4 years of experience
		WebElement exp=driver.findElement(RelativeLocator.with(By.xpath("//div[3]/div/span")).toRightOf(location));
		exp.click();
		driver.findElement(By.linkText("4")).click();
		WebDriverWait w = new WebDriverWait(driver,Duration.ofSeconds(5));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("icon-glyph-1")));
		//search button
		driver.findElement(By.className("icon-glyph-1")).click();
		WebDriverWait w1 = new WebDriverWait(driver,Duration.ofSeconds(5));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[5]")));
		String expLoc="ThiruvananthapuramX";
		String actLoc = driver.findElement(By.xpath("//span[5]")).getText();
		assertEquals(actLoc, expLoc);
		
	}
	@AfterMethod
	public void afterMethod(ITestResult result)
	{
	    try
	 {
	    if(result.getStatus() == ITestResult.SUCCESS)
	    {

	        //Do something here
	        System.out.println("passed **********");
	    }

	    else if(result.getStatus() == ITestResult.FAILURE)
	    {
	    	ScreenshotUst ss= new ScreenshotUst();
	    	ss.takeScreenShot(driver);
	         //Do something here
	        System.out.println("Failed ***********");

	    }

	     else if(result.getStatus() == ITestResult.SKIP ){

	        System.out.println("Skiped***********");

	    }
	}
	   catch(Exception e)
	   {
	     e.printStackTrace();
	   }

	}
  
}
