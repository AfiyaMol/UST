package karate;

import com.intuit.karate.junit5.Karate;

public class KarateRunner {
	@Karate.Test
	Karate karateTest() {
		return Karate.run("FreeFakeAPI.feature").tags("patch").relativeTo(getClass());
		
	}

}
