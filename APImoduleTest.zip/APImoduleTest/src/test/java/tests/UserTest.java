package tests;

import static org.testng.Assert.assertEquals;

import java.io.File;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import org.testng.ITestListener;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.Routes;
import endpoints.UserEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payloads.Usermodel;

import utilities.ExtentReportsListener;

@Listeners(utilities.ExtentReportsListener.class)
public class UserTest{

	public Usermodel userPayload;
	
	@BeforeClass
	public void setup() {
		userPayload=new Usermodel("This is the comment content",1,5);
	}
	@Test(priority = 1)
	public void getAllComments() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.getAllComments(1);
		 response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
		 response.then().assertThat().body(matchesJsonSchema(
					new File(System.getProperty("user.dir")+"\\src\\test\\resources\\payload\\getAll.json")));
		}
	
	@Test(priority = 2)
	public void getSingleComments() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.getSingleComment(1);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
		 response.then().assertThat().body(matchesJsonSchema(
					new File(System.getProperty("user.dir")+"\\src\\test\\resources\\payload\\getSingle.json")));
	}
	
	
	@Test(priority = 3)
	public void postComments() {
		Usermodel userPayload1=new Usermodel();
		userPayload1=new Usermodel("This is the comment content",1,5);
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.createComments(userPayload1);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 201);
		 response.then().assertThat().body(matchesJsonSchema(
					new File(System.getProperty("user.dir")+"\\src\\test\\resources\\payload\\post.json")));
	}

	@Test(priority = 4)
	public void putComments() {
		RestAssured.useRelaxedHTTPSValidation();
		Usermodel userPayload2=new Usermodel();
		userPayload2=new Usermodel("This is the comment content",1,5);
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.updateComments(1, userPayload2);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 400);
		 response.then().assertThat().body(matchesJsonSchema(
					new File(System.getProperty("user.dir")+"\\src\\test\\resources\\payload\\put.json")));
	}
	
	@Test(priority = 5)
	public void patchComments() {
		Usermodel userPayload2=new Usermodel();
		userPayload2=new Usermodel("This is the comment content",1,5);
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.patchUpdateComments(1, userPayload2);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
		 response.then().assertThat().body(matchesJsonSchema(
					new File(System.getProperty("user.dir")+"\\src\\test\\resources\\payload\\patch.json")));
	}
	
	@Test(priority = 6)
	public void deleteComments() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.deleteComments(1);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 204);
	}
	}
