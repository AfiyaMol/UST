package endpoints;

//main class to declare all the url
public class Routes {

	public static String baseUri="https://freefakeapi.io";
	public static String getAll="/api/comments";
	public static String getSingle="/api/comments/{id}";
	public static String post="/api/comments";
	public static String put="/api/comments/{id}";
	public static String patch="/api/comments/{id}";
	public static String delete="/api/comments/{id}";
	
}
