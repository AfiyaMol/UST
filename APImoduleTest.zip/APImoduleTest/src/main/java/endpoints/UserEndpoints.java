package endpoints;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payloads.Usermodel;
//to get all the user end points
public class UserEndpoints {

	public static Response getAllComments(long id) {
		Response response = RestAssured.given()
				.headers("Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.getAll)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;	
	}
	
	
	public static Response getSingleComment(long id) {
		Response response = RestAssured.given()
				.headers("Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.getSingle)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;	
	}
		
	
	public static Response createComments(Usermodel payload) {
		Response response = RestAssured.given()
				.headers("Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.post)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;	
	}
	
 
	public static Response updateComments(long id, Usermodel payload) {
		
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.put)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.put();
		return response;	
	}
	
	
	public static Response patchUpdateComments(long id, Usermodel payload) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.patch)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.patch();
		return response;	
	}
	
	public static Response deleteComments(long id) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.delete)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.delete();
		return response;	
	}
		
}





