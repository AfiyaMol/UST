package payloads;

public class Usermodel {

	
	public String content;
	public int user;
	public int post;
	
	
	public Usermodel() {
	}
	
	public Usermodel(String content ,int user, int post) {
		this.content=content;
		this.user=user;
		this.post=post;
	}

	
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getUser() {
		return user;
	}

	public void setUser(int user) {
		this.user = user;
	}

	public int getPost() {
		return post;
	}

	public void setPost(int post) {
		this.post = post;
	}

	@Override
    public String toString() {
        return "Data{" +
                "content=" + content +
                ", user='" + user + '\'' +
                ", post=" + post  +
                '}';
  }
}
