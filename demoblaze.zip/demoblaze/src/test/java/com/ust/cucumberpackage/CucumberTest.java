package com.ust.cucumberpackage;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

import com.ust.pagefactory.AddtoCartCucs;
import com.ust.reusables.Browser;
import com.ust.utilities.ObjectConfig;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
public class CucumberTest {
	WebDriver driver;
	Properties prop ;
	AddtoCartCucs ac;

	@Before
	public void setup() throws IOException, InterruptedException {
		prop = ObjectConfig.initProperties();
		driver = Browser.invokeBrowser(prop.getProperty("browserName"));
		driver.get(ObjectConfig.initProperties().getProperty("url"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}

	@After
	public void teardown() throws InterruptedException {
		driver.close();
	}
	
	@Given("user in home page and clicks any product")
	public void user_in_home_page_and_clicks_any_product() {
	    ac = new AddtoCartCucs(driver);
	    ac.purchase();
	}

	@And("user navigated to result page and selected particular product")
	public void user_navigated_to_result_page_and_selected_particular_product()  {
	   ac.product();
	}

	@And("user clicked add to cart")
	public void user_clicked_add_to_cart() throws InterruptedException  {
	   ac.addtoCart();
	}

	@And("Cart icon on top is clicked")
	public void cart_icon_on_top_is_clicked()  {
	    ac.cartIcon();
	}

	@Then("user navigated to place order page")
	public void user_navigated_to_place_order_page()  {
		
		String result=ac.prodName();
		  assertTrue(result.contains(prop.getProperty("productname")));
		  Browser.wait(5000);
		  ac.orderplaced();
	}
}
