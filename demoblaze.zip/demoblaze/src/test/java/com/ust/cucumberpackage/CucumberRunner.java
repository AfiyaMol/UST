package com.ust.cucumberpackage;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		features = {"C:\\Users\\272317\\JavaProject\\demoblaze\\src\\test\\java\\com\\ust\\cucumberpackage\\cucumber.feature"},
		glue = {"com.ust.cucumberpackage"},
		tags= "@addtocart"
//		publish = true,
//		plugin = {"me.jvt.cucumber.report.PrettyReports:Reports"}
		)
public class CucumberRunner extends AbstractTestNGCucumberTests{

}
