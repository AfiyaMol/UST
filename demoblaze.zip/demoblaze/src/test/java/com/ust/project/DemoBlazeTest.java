package com.ust.project;





import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.pagefactory.LoginDemoBlaze;
import com.ust.reusables.Browser;
import com.ust.utilities.ExcelReader;
import com.ust.utilities.ExtentReportsListener;
import com.ust.utilities.ObjectConfig;
@Listeners(ExtentReportsListener.class)
public class DemoBlazeTest {
	WebDriver driver;
	LoginDemoBlaze ldb;
	Properties prop;
	@BeforeMethod
	public void setUp() {            
        //to get the data from object.properties file
		prop = ObjectConfig.initProperties();
		driver = Browser.invokeBrowser(prop.getProperty("browserName"));
		driver.get(ObjectConfig.initProperties().getProperty("url"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}
	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
	@Test(dataProvider = "dp")
	public void login(String username, String password, String validate) throws InterruptedException {
		ldb= new LoginDemoBlaze(driver);
		ldb.title();
		ldb.login();
		ldb.user(username);
		ldb.pass(password);
		if(validate.equals("valid")) {
			ldb.loginbutton1();
			Browser.wait(2000);

		assertEquals(ldb.welcome(), prop.getProperty("exptext"));
		Browser.wait(7000);

		ldb.contact(prop.getProperty("email"), prop.getProperty("name"));
		Browser.wait(7000);
	
		ldb.logoutbutton();
		Browser.wait(7000);
		//assertEquals(ldb.pageUrl().contains("index.html"));
		
		assertEquals(ldb.pageUrl().contains("index.html"), true);
		System.out.println("Logged out");
	}
		else {
			ldb.loginbutton();
			String message="";
			try {
				WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(50));
				wait.until(ExpectedConditions.alertIsPresent());
				Alert alert = driver.switchTo().alert();
				message = alert.getText();
				System.out.println(message);
				alert.accept();
			}
			catch(NoAlertPresentException e) {
				System.out.println("No alert found!");
				Browser.wait(7000);
				driver.switchTo().alert().accept();
			    assertTrue(true);
			}
		}
	}	
	@DataProvider
	public String[][] dp() throws IOException {
		String path = "C:\\Users\\272317\\JavaProject\\project\\src\\test\\resources\\datasource\\dataset.xlsx";
		String sheetName = "Sheet1";
		String data[][] = ExcelReader.getData(path, sheetName);
		return data;
	}
}
