package com.ust.driverimplementatiom;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class DriverConfig {
private static WebDriver driver;
public static WebDriver getChromeDriver() {
	ChromeOptions co = new ChromeOptions();//class to manage chrome driver
	co.addArguments("--disable-infobars");
	co.addArguments("--disable-notifications");
	co.addArguments("--start-maximized");
	driver = new ChromeDriver(co);
	driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
	return driver;
}

public static WebDriver getMSEdgeDriver() {
	ChromeOptions co = new ChromeOptions();
	co.addArguments("--disable-infobars");
	co.addArguments("--disable-notifications");
	co.addArguments("--start-maximized");
	driver = new ChromeDriver(co);
	driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
	return driver;
}
}
