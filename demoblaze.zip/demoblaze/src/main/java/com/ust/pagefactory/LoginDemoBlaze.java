package com.ust.pagefactory;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.reusables.Browser;
//scenario1= login
//scenario2=contact 
//scenario3=logout
public class LoginDemoBlaze {
WebDriver driver;
	
	public LoginDemoBlaze(WebDriver driver){
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(linkText ="Log in")
	WebElement loginIcon;
	@FindBy(id="loginusername")
	WebElement username;
	@FindBy(id="loginpassword")
	WebElement pswd;
	@FindBy(xpath="(//button[@class='btn btn-primary'])[3]")
	WebElement loginButton;
	@FindBy(linkText = "Welcome Afiya")
	WebElement succtext;
	@FindBy(linkText = "Log out")
	WebElement logoutButton;
	@FindBy(linkText = "Contact")
	WebElement contact; 
	@FindBy(className ="form-control")
	WebElement contactemail;
	@FindBy(id ="recipient-name")
	WebElement contactname;
	@FindBy(xpath="(//button[@class='btn btn-primary'])[1]")
	WebElement sendmsg;	
	
	public String title() {
		return driver.getTitle();
	}
	public void login() {
		loginIcon.click();
	}
	public void user(String uname) {
		username.clear();
		username.sendKeys(uname);
	}
	public void pass(String pword) {
		pswd.clear();
		pswd.sendKeys(pword);
	}
	public void loginbutton()  {
		loginButton.click();
		
		
		
	
	}
	public String welcome() {
		return succtext.getText();
	}
	public void logoutbutton() {
		logoutButton.click();
	}
	
	public void contact(String email , String name) {
	//	driver.switchTo().alert().accept();
	
		contact.click();
	Browser.wait(2000);
		contactemail.sendKeys(email);
		contactname.sendKeys(name);
		sendmsg.click();
		driver.switchTo().alert().accept();
		
	}
	public void loginbutton1() throws InterruptedException {
		loginButton.click();
	}
	public String pageUrl() {
		return driver.getCurrentUrl();
	}
	}


