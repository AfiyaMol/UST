package com.ust.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddtoCartCucs {
	WebDriver driver;

	@FindBy(linkText ="Laptops")
	WebElement phones;
	@FindBy(linkText = "Sony vaio i5")
	WebElement prod;
	@FindBy(linkText = "Add to cart")
	WebElement add;
	@FindBy(linkText = "Cart")
	WebElement carticon;
	@FindBy(xpath="//button[@class='btn btn-success']")
	WebElement placeorder;
	@FindBy(css="#tbodyid > tr > td:nth-child(2)")
	WebElement prodname;

	public AddtoCartCucs(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	public void purchase() {
		phones.click();
	}
	public void product() {
		prod.click();
	}
	public void addtoCart() throws InterruptedException {
		add.click();
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
	}
	public void cartIcon() {
		carticon.click();
	}
	public void orderplaced() {
		placeorder.click();
	}
	public String prodName() {
		return prodname.getText();
	}
}
