package jenkins;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import utils.ScreenshotJenkins;

public class JenkinsFeedback {
	WebDriver driver;
	
  @Test
  public void verifyJenkins() {
		 driver.findElement(By.xpath("//div[2]/div[3]/div/a[2]")).click(); // click documentation
		 driver.findElement(By.xpath("//ul[2]/li[1]/a")).click();//Tutorials secƟon click Guided Tour
		 driver.findElement(By.xpath("//div[2]/div[3]/p/a")).click();// Click “Was this page helpful?”
		 driver.findElement(By.xpath("(//input[@id='h1'])")).click();// click radio buttton yes
		 
		String text = driver.findElement(By.xpath("//label[@id='ssTestLabel']")).getText(); // Text from label
		String[] numbers = text.split("\\s+");
		int num1 = Integer.parseInt(numbers[4]);
		int num2 = Integer.parseInt(numbers[6]);
		int sum = num1 + num2;
		driver.findElement(By.xpath("//input[@name='ssTestValue']")).sendKeys(String.valueOf(sum)); // Text field
		driver.findElement(By.xpath("//p[3]/button")).click();
		String expMsg="Thank you for your feedback!";
		String actMsg=driver.findElement(By.xpath("(//h3[@id='thank-you-for-your-feedback'])")).getText();
		assertEquals(actMsg, expMsg);
		}
  @BeforeMethod
  public void beforeMethod() {
		  driver = new ChromeDriver();
		  driver.get("https://www.jenkins.io");
		  driver.manage().window().maximize();
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(7));
	  
  }

  @AfterMethod
	public void afterMethod(ITestResult result)
	{
	    try
	 {
	    if(result.getStatus() == ITestResult.SUCCESS)
	    {

	        //Do something here
	        System.out.println("passed **********");
	    }

	    else if(result.getStatus() == ITestResult.FAILURE)
	    {
	    	ScreenshotJenkins ss= new ScreenshotJenkins();
	    	ss.takeScreenShot(driver);
	         //Do something here
	        System.out.println("Failed ***********");

	    }

	     else if(result.getStatus() == ITestResult.SKIP ){

	        System.out.println("Skiped***********");

	    }
	}
	   catch(Exception e)
	   {
	     e.printStackTrace();
	   }

	}

}
