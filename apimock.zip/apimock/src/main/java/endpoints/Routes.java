package endpoints;

public class Routes {

	public static String baseUri="https://dummy.restapiexample.com";
	public static String get_all="/api/v1/employees";
	public static String get_single="/api/v1/employee/{id}";
	public static String post="/api/v1/create";
	public static String put="/api/v1/update/{id}";
	public static String delete="/api/v1/delete/{id}";
	
	//public static String baseUrii="https://reqres.in/api/users/2";
}
