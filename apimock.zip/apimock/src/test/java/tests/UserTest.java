package tests;

import static org.testng.Assert.assertEquals;

import java.io.File;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;

import org.testng.ITestListener;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.Routes;
import endpoints.UserEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payloads.Usermodel;
import utilities.ExtentReportsListener;

@Listeners(utilities.ExtentReportsListener.class)
public class UserTest{

	public Usermodel userPayload;
	
	@BeforeClass
	public void setup() {
		userPayload=new Usermodel("test", "123", "23");
	}
	@Test
	public void getSingleUser() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.getSingleUser(1);
		 response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	@Test
	public void getListUsers() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.getAllUser(1);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	@Test
	public void deleteUser() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.deleteUser(1);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 204);
	}
	
	@Test
	public void postUser() {
		Usermodel userPayload1=new Usermodel();
		userPayload1=new Usermodel("test", "123", "23");
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.createUser(userPayload1);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 201);
	}
	
	@Test
	public void putUser() {
		Usermodel userPayload2=new Usermodel();
		userPayload2=new Usermodel("test", "123", "23");
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndpoints.updateUser(100, userPayload2);
		response.then().log().all();
		 assertEquals(response.getStatusCode(), 200);
	}
	
	
	@Test //getAll
    public void schemavalidationgetAll() {
	 RestAssured.useRelaxedHTTPSValidation();
	    RestAssured.given()
	    .baseUri(Routes.baseUri)
	        .when()
	        .get()
	        .then()
	        .assertThat()
	        .body(matchesJsonSchema(new File("C:\\Users\\272317\\JavaProject\\apimock\\src\\test\\resources\\payload\\getAll.json")));
	}
	
	@Test 
    public void schemavalidationgetSingle() {
	 RestAssured.useRelaxedHTTPSValidation();
	    RestAssured.given()
	    .baseUri(Routes.baseUri)
	        .when()
	        .get()
	        .then()
	        .assertThat()
	        .body(matchesJsonSchema(new File("C:\\Users\\272317\\JavaProject\\apimock\\src\\test\\resources\\payload\\getAll.json")));
	}
	@Test 
    public void schemavalidationCreate() {
	 RestAssured.useRelaxedHTTPSValidation();
	    RestAssured.given()
	    .baseUri(Routes.baseUri)
	        .when()
	        .post()
	        .then()
	        .assertThat()
	        .body(matchesJsonSchema(new File("C:\\Users\\272317\\JavaProject\\apimock\\src\\test\\resources\\payload\\create.json")));
	}
	@Test 
    public void schemavalidationgetUpdate() {
	 RestAssured.useRelaxedHTTPSValidation();
	    RestAssured.given()
	    .baseUri(Routes.baseUri)
	        .when()
	        .put()
	        .then()
	        .assertThat()
	        .body(matchesJsonSchema(new File("C:\\Users\\272317\\JavaProject\\apimock\\src\\test\\resources\\payload\\update.json")));
	}
	@Test 
    public void schemavalidationgetDelete() {
	 RestAssured.useRelaxedHTTPSValidation();
	    RestAssured.given()
	    .baseUri(Routes.baseUri)
	        .when()
	        .delete()
	        .then()
	        .assertThat()
	        .body(matchesJsonSchema(new File("C:\\Users\\272317\\JavaProject\\apimock\\src\\test\\resources\\payload\\delete.json")));
	}
}
