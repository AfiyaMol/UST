package goibibotestcase;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestGoibibo {
	WebDriver driver;
	
  @Test
  public void dateVerify() throws InterruptedException {
	  driver.findElement(By.xpath("(//span[@class='logSprite icClose'])")).click();
	  driver.findElement(By.xpath("(//p[@class='sc-12foipm-4 czGBLf fswWidgetTitle'])[1]")).click();
	  while (!driver.findElement(By.xpath("//div[3]/div[2]/div/div/div/div[2]/div[2]/div[1]/div")).getText().contains("December")) {
	  driver.findElement(By.xpath("(//span[@class='DayPicker-NavButton DayPicker-NavButton--next'])")).click();}
	  driver.findElement(By.xpath("(//div[@aria-label='Tue Dec 17 2024'])")).click();
	  WebElement element = driver.findElement(By.xpath("(//p[@class='sc-12foipm-4 czGBLf fswWidgetTitle'])[1]"));
	  System.out.println(element.getText());
		assertEquals(true, element.getText().contains("17 Dec'24"));

  }
  @BeforeMethod
  public void beforeMethod() {
	  driver = new ChromeDriver();
	  driver.get("https://www.goibibo.com/");
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
  }

  @AfterMethod
  public void afterMethod() {
	//  driver.quit();
  }

}
