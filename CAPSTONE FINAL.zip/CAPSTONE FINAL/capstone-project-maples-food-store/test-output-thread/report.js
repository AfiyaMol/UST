$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"05fb4c5b-cb0c-4dc9-afd5-f2f1d785e279","feature":"SortBy filter functionality","scenario":"Sorting the products","start":1717849287590,"group":1,"content":"","tags":"@tag,@tag1,","end":1717849299280,"className":"failed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});