package com.ust.Maples.dataproviders;

import java.io.FileReader;
import java.io.IOException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.annotations.DataProvider;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ust.Maples.utils.ExcelReader;



//--------------------DATA PROVIDER IMPLEMENTATION--------------------//

public class DataProviderUtility {

	// PATH OF THE EXCEL DATA SHEET
	public static final String EXCELPATH = System.getProperty("user.dir") + "\\src\\test\\resources\\DataSource\\TestData.xlsx";
	// PATH OF THE JSON FILE
	public static final String JSONPATH = System.getProperty("user.dir") + "\\src\\test\\resources\\DataSource\\registeruser.json";
	// PATH OF THE JSON FILE FOR GSON
	public static final String NEWJSONPATH = System.getProperty("user.dir") + "\\src\\test\\resources\\DataSource\\registerusernewui.json";

	// DATA PROVIDER FOR EMAIL DATA IN SIGN UP
	@DataProvider (name = "emailForSignUp")
	public Object[][] getEmailForSignUp() {
		return new Object[][] { 
			{"mariyaroy15@gmail.com", "Valid"},
			{"mariyaroy04@gmail.com", "Existing"},
			{"mariya$23#gmail.com", "Invalid"}
		};
	}

	@DataProvider(name = "LoginData")
	public Object[][] validCond() throws IOException {

		/* To check if the data is fetched from excel
		 System.out.println("-----------Inside DataProvider-----------");
		 String[][] data = ExcelReader.getExcelData(EXCELPATH, "Login");
		 int rows = ExcelReader.getRowNumber(EXCELPATH, "Login");
		 int cols = ExcelReader.getColumnNumber(EXCELPATH, "Login");
		 for(int i = 0; i < rows; i++) {
			 for(int j = 0; j < cols; j++) {
				 System.out.print(data[i][j] + " ");
			 }
			 System.out.print("\n");
		 } */

		return ExcelReader.getExcelData(EXCELPATH, "Login");
	}

	// DATA PROVIDER FOR EMAIL DATA IN SIGN UP USING JSON FILE
	@DataProvider(name = "emailUsingJson")
	public Object[] readjson() throws IOException, ParseException {
		JSONParser jsonParser = new JSONParser(); // Used to parse JSON files

		FileReader fileReader = new FileReader(JSONPATH);
		Object obj = jsonParser.parse(fileReader); // Parses the JSON file and stores the result as an Object

		JSONArray array = (JSONArray) obj;

		String arr[] = new String[array.size()];
		for (int i = 0; i < array.size(); i++) {
			JSONObject users = (JSONObject) array.get(i);
			String email = (String) users.get("email");
			String type = (String) users.get("type");

			arr[i] = email+","+type;
		}
		return arr;
	}

	// DATA PROVIDER FOR EMAIL DATA IN SIGN UP USING GSON LIBRARY
	@SuppressWarnings("deprecation")
	@DataProvider(name = "emailUsingGson")
	public Object[] readUsingGson() {
		String[] arr = null;

		try (FileReader fileReader = new FileReader(NEWJSONPATH)) { // Java 7 feature: try-with-resources statement		 

			JsonParser parser = new JsonParser();
			JsonElement tree = parser.parse(fileReader);
			JsonArray array = tree.getAsJsonArray();
			arr = new String[array.size()];

			int i = 0;

			for (JsonElement element: array) {
				if (element.isJsonObject()) {
					JsonObject users = element.getAsJsonObject();
					String username = users.has("username") ? users.get("username").getAsString() : "";
					String email = users.has("email") ? users.get("email").getAsString() : "";
					String password = users.has("password") ? users.get("password").getAsString() : "";
					String type = users.has("type") ? users.get("type").getAsString() : "";

					arr[i] = username + "," + email + "," + password + "," + type;
					i++;
				}

			}

		} 
		catch (IOException e) {
			System.out.println("Error reading JSON file: " + e.getMessage());
		}
		return arr;
	}
	
	@DataProvider(name = "PlaceOrder")
	public Object[][] placeOrder() throws IOException {

		/* To check if the data is fetched from excel
		 System.out.println("-----------Inside DataProvider-----------");
		 String[][] data = ExcelReader.getExcelData(EXCELPATH, "PlaceOrder");
		 int rows = ExcelReader.getRowNumber(EXCELPATH, "PlaceOrder");
		 int cols = ExcelReader.getColumnNumber(EXCELPATH, "PlaceOrder");
		 for(int i = 0; i < rows; i++) {
			 for(int j = 0; j < cols; j++) {
				 System.out.print(data[i][j] + " ");
			 }
			 System.out.print("\n");
		 } */

		return ExcelReader.getExcelData(EXCELPATH, "PlaceOrder");
	}
	
	@DataProvider(name = "AddressLogin")
	public Object[][] login() throws IOException {
		return ExcelReader.getExcelData(EXCELPATH, "MyAccountLogin");
	}
	
	@DataProvider(name = "BAddress")
	public Object[][] billing() throws IOException {
		return ExcelReader.getExcelData(EXCELPATH, "BillingAddress");
	}
	
	@DataProvider(name = "SAddress")
	public Object[][] shipping() throws IOException {
		return ExcelReader.getExcelData(EXCELPATH, "ShippingAddress");
	}
	
	@DataProvider(name = "AccDetails")
	public Object[][] accountdetails() throws IOException {
		return ExcelReader.getExcelData(EXCELPATH, "AccountDetails");
	}

}
