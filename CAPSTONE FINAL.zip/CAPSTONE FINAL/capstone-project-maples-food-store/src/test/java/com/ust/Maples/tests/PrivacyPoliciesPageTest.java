package com.ust.Maples.tests;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Maples.base.Setup;
import com.ust.Maples.pages.HomePage;
import com.ust.Maples.pages.PrivacyPolicy;
import com.ust.Maples.testlistener.ExtentReportListener;


//AUTHOR: ARDRA A

//--------------------PRIVACY POLICY PAGE VALIDATION--------------------//

@Listeners(ExtentReportListener.class)
public class PrivacyPoliciesPageTest extends Setup
{
  
	public WebDriver driver;
	public HomePage home;
	public PrivacyPolicy privacy;
	
	
  @BeforeClass
  public void beforeClass() 
  {
	  driver = invokeBrowser(prop.getProperty("Browser"));
	  home = new HomePage(driver);
	  driver.get(prop.getProperty("BaseUrl"));
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(7)); // IMPLICIT WAIT
	  
  }
  
  @Test(priority=1,description="Checking the privacy policy page")
  public void verifyPrivacyPolicy() 
  {
	  privacy=(PrivacyPolicy) home.clickElementAndReturnDriver(home.privacyPolicyLink, new PrivacyPolicy(driver));
	  assertEquals(privacy.getPrivacyText(privacy.privacyText),prop.getProperty("PrivacyText"));
  }

  @AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit(); // QUIT THE WEBDRIVER INSTANCE
		}
	}



}
