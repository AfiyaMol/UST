package com.ust.Maples.tests;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Maples.base.Setup;
import com.ust.Maples.pages.HomePage;
import com.ust.Maples.pages.ProductDetailsPage;
import com.ust.Maples.pages.WishlistPage;
import com.ust.Maples.testlistener.ExtentReportListener;



//AUTHOR: MARIYA ROY

//--------------------WISHLIST VALIDATION--------------------//

@Listeners(ExtentReportListener.class)
public class WishlistPageTest extends Setup {

	public WebDriver driver;
	public HomePage home;
	public ProductDetailsPage details;
	public WishlistPage wishlist;
	
	@BeforeClass
	public void setup() {
		driver = invokeBrowser(prop.getProperty("Browser"));
		home = new HomePage(driver);
		driver.get(prop.getProperty("BaseUrl"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5)); // IMPLICIT WAIT
	}
	
	@Test (priority = 0, description = "Add product to wishlist")
	public void verifyAddToWishlist() throws InterruptedException {
		details = (ProductDetailsPage) home.clickElementAndReturnDriver(home.pdtAddedTocart, new ProductDetailsPage(driver)); // CLICKING A PRODUCT FROM HOME PAGE
		details.clickElement(details.wishlistLink);  // CLICKING WISHLIST LINK IN PRODUCT DETAILS PAGE
		wait(5);
		String qty = home.getText(home.navBarWishlistQty); // FETCHING QUANTITY FROM WISHLIST ICON IN THE NAV BAR
		
		assertEquals(qty, prop.getProperty("WishlistQty"));
	}
	
	@Test (priority = 1, description = "Verifying browse wishlist functionality")
	public void verifyBrowseWishlist() throws InterruptedException {
		wishlist = (WishlistPage) details.clickElementAndReturnDriver(details.browseWishlist, new WishlistPage(driver)); // CLICKING THE BROWSE WISHLIST LINK
		wait(5);
		assertEquals(wishlist.getText(wishlist.heading), prop.getProperty("WishlistPageTitle"));
	}
	
	@Test (priority = 2, description = "Verifying remove from wishlist")
	public void verifyRemoveFromWishlist() {
		home.clickElement(home.navBarWishlistIcon); // CLICKING THE WISHLIST ICON IN NAV BAR
		wishlist.clickElement(wishlist.removeIcon);
		assertEquals(wishlist.getText(wishlist.emptyWishlistMsg), prop.getProperty("EmptyWishlist"));
	}
	
	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit(); // QUIT THE WEBDRIVER INSTANCE
		}
	}

}
