package com.ust.Maples.tests;

import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Maples.base.Setup;
import com.ust.Maples.dataproviders.DataProviderUtility;
import com.ust.Maples.pages.HomePage;
import com.ust.Maples.pages.MyAccountPage;
import com.ust.Maples.pages.SignUpPage;
import com.ust.Maples.testlistener.ExtentReportListener;


//AUTHOR: MARIYA ROY

//--------------------SIGN UP VALIDATION--------------------//

@Listeners(ExtentReportListener.class)
public class SignUpPageTest extends Setup {

	public WebDriver driver;
	public HomePage home;
	public SignUpPage signup;
	public MyAccountPage account;

	@BeforeClass
	public void setup() {
		driver = invokeBrowser(prop.getProperty("Browser"));
		home = new HomePage(driver);
		driver.get(prop.getProperty("BaseUrl"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(7)); // IMPLICIT WAIT
	}

	@Test (priority = -1)
	public void verifySignUpWithNullData() {
		signup = (SignUpPage) home.clickElementAndReturnDriver(home.signUpLink, new SignUpPage(driver)); // CLICKING THE SIGN UP LINK IN HOME PAGE
		account = (MyAccountPage) signup.clickElementAndReturnDriver(signup.registerBtn, new MyAccountPage(driver)); // CLICKING THE REGISTER BUTTON IN SIGN UP PAGE

		assertTrue(account.getText(signup.errorMessage).contains(prop.getProperty("NoEmailErrorMsg")), "Validation failed for no email scenario!");
	}

	// USING DATAPROVIDER
	@Test (priority = 0, dataProvider = "emailForSignUp", dataProviderClass = DataProviderUtility.class, enabled = false)
	public void verifySignUp(String email, String type) {

		home.clickElement(home.signUpLink); // CLICKING THE SIGN UP LINK IN HOME PAGE
		signup.sendText(email, signup.email); // ENTERING EMAIL ID
		signup.clickElement(signup.registerBtn); // CLICKING THE REGISTER BUTTON IN SIGN UP PAGE

		if(type.equals("Valid")) {
			assertTrue(account.getText(account.welcomeText).contains(prop.getProperty("WelcomeMsg")), "Validation failed for valid email scenario!");
			account.clickElement(account.logoutLink);
		}
		else if(type.equals("Invalid")) {
			assertTrue(signup.isDisplayed(signup.registerBtn), "Validation failed for invalid email scenario!");
		}
		else if(type.equals("Existing")) {
			assertTrue(account.getText(signup.errorMessage).contains(prop.getProperty("ExistingEmailErrorMsg")), "Validation failed for existing email scenario!");
			signup.goBack();
		}
	}

	// USING DATAPROVIDER AND JSON
	@Test(priority = 1, dataProvider="emailUsingJson",  dataProviderClass = DataProviderUtility.class, enabled = false)
	public void login(String data) {
		String email[] = data.split(",");

		home.clickElement(home.signUpLink); // CLICKING THE SIGN UP LINK IN HOME PAGE
		signup.sendText(email[0], signup.email); // ENTERING EMAIL ID
		signup.clickElement(signup.registerBtn); // CLICKING THE REGISTER BUTTON IN SIGN UP PAGE

		if(email[1].equals("Valid")) {
			assertTrue(account.getText(account.welcomeText).contains(prop.getProperty("WelcomeMsg")), "Validation failed for valid email scenario!");
			account.clickElement(account.logoutLink);
		}
		else if(email[1].equals("Invalid")) {
			assertTrue(signup.isDisplayed(signup.registerBtn), "Validation failed for invalid email scenario!");
		}
		else if(email[1].equals("Existing")) {
			assertTrue(account.getText(signup.errorMessage).contains(prop.getProperty("ExistingEmailErrorMsg")), "Validation failed for existing email scenario!");
			signup.goBack();
		}

	}

	// USING DATAPROVIDER AND GSON
	@Test(priority = 2, dataProvider="emailUsingGson",  dataProviderClass = DataProviderUtility.class)
	public void loginWithGson(String data) {
		String email[] = data.split(",");

		home.clickElement(home.signUpLink); // CLICKING THE SIGN UP LINK IN HOME PAGE
		signup.sendText(email[0], signup.username); // ENTERING USERNAME
		signup.sendText(email[1], signup.email); // ENTERING EMAIL ID
		signup.sendText(email[2], signup.password); // ENTERING PASSWORD
		signup.clickElement(signup.registerBtn); // CLICKING THE REGISTER BUTTON IN SIGN UP PAGE

		if(email[3].equals("Valid")) {
			//assertTrue(account.getText(account.welcomeText).contains(prop.getProperty("WelcomeMsg")), "Validation failed for valid email scenario!");
			assertTrue(account.getText(account.welcomeText).contains(prop.getProperty("SignUpWelcomeMsg")), "Validation failed for valid email scenario!");
			account.clickElement(account.logoutLink);
		}
		else if(email[3].equals("Invalid")) {
			assertTrue(signup.isDisplayed(signup.registerBtn), "Validation failed for invalid email scenario!");
		}
		else if(email[3].equals("Existing")) {
			//assertTrue(account.getText(signup.errorMessage).contains(prop.getProperty("ExistingEmailErrorMsg")), "Validation failed for existing email scenario!");
			assertTrue(account.getText(signup.errorMessage).contains(prop.getProperty("ExistingEmail")), "Validation failed for existing email scenario!");
			signup.goBack();
		}

	}

	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit(); // QUIT THE WEBDRIVER INSTANCE
		}
	}



}
