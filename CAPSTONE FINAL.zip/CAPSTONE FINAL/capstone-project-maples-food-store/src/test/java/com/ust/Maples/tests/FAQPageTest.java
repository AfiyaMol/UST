package com.ust.Maples.tests;

import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Maples.base.Setup;
import com.ust.Maples.pages.FAQsPage;
import com.ust.Maples.pages.HomePage;
import com.ust.Maples.testlistener.ExtentReportListener;


//AUTHOR: ARDRA A

//--------------------FAQ PAGE VALIDATION--------------------//

@Listeners(ExtentReportListener.class)
public class FAQPageTest extends Setup
{

	public WebDriver driver;
	public HomePage home;
	public FAQsPage faq;

	@BeforeClass
	public void beforeClass()
	{
		driver = invokeBrowser(prop.getProperty("Browser"));
		home = new HomePage(driver);
		driver.get(prop.getProperty("BaseUrl"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(7)); // IMPLICIT WAIT

	}

	@Test(priority=1,description="Checking the FAQ page")
	public void testFAQPageContent()
	{
		faq=(FAQsPage) home.clickElementAndReturnDriver(home.faqLink, new FAQsPage(driver));
		assertTrue(faq.getTextFaq(faq.faqText).contains(prop.getProperty("FaqText")), "FAQ text mismatch");

	}


	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit(); // QUIT THE WEBDRIVER INSTANCE
		}
	}


}
