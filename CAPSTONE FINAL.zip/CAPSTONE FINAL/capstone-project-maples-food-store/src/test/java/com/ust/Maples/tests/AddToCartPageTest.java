package com.ust.Maples.tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Maples.base.Setup;
import com.ust.Maples.dataproviders.DataProviderUtility;
import com.ust.Maples.pages.AddToCartPage;
import com.ust.Maples.pages.CheckoutPage;
import com.ust.Maples.pages.HomePage;
import com.ust.Maples.pages.PlaceOrderPage;
import com.ust.Maples.pages.ProductDetailsPage;
import com.ust.Maples.testlistener.ExtentReportListener;



//AUTHOR: MARIYA ROY

//--------------------ADD TO CART VALIDATION--------------------//

@Listeners(ExtentReportListener.class)
public class AddToCartPageTest extends Setup {

	public WebDriver driver;
	public HomePage home;
	public AddToCartPage add;
	public ProductDetailsPage details;
	public CheckoutPage checkout;
	public PlaceOrderPage order;
	
	@BeforeClass
	public void setup() {
		driver = invokeBrowser(prop.getProperty("Browser"));
		home = new HomePage(driver);
		driver.get(prop.getProperty("BaseUrl"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5)); // IMPLICIT WAIT
	}
	
	@Test (priority = -1, description = "Add product to cart", enabled = false)
	public void verifyAddToCart() {
		details = (ProductDetailsPage) home.clickElementAndReturnDriver(home.pdtAddedTocart, new ProductDetailsPage(driver)); // CLICKING A PRODUCT FROM HOME PAGE
		details.clickElement(details.addToCartBtn); // CLICKING ADD TO CART BUTTON IN PRODUCT DETAILS PAGE
		int hqty = Integer.parseInt(home.getText(home.navBarCartQty)); // FETCHING QUANTITY FROM CART ICON IN THE NAV BAR
		add = (AddToCartPage) home.clickElementAndReturnDriver(home.navBarCartIcon, new AddToCartPage(driver)); // CLICKING THE CART ICON IN NAV BAR
		int cqty = Integer.parseInt(add.getAttributeValue(add.quantity, prop.getProperty("CartPageAttributeForQuantity"))); // FETCHING QUANTITY FROM CART PAGE

		assertEquals(hqty, cqty);
	}
	
	@Test (priority = -1, description = "Add product to cart (based on new UI)")
	public void verifyAddToCartNew() {
		details = (ProductDetailsPage) home.clickElementAndReturnDriver(home.pdtAddedTocart, new ProductDetailsPage(driver)); // CLICKING A PRODUCT FROM HOME PAGE
		details.clickElement(details.addToCartBtn); // CLICKING ADD TO CART BUTTON IN PRODUCT DETAILS PAGE
		add = (AddToCartPage) details.clickElementAndReturnDriver(details.viewCartBtn, new AddToCartPage(driver)); // CLICKING THE VIEW CART ICON IN PRODUCT DETAILS PAGE>
		String cqty = add.getAttributeValue(add.quantity, prop.getProperty("CartPageAttributeForQuantity")); // FETCHING QUANTITY FROM CART PAGE

		assertEquals(prop.getProperty("CartQty"), cqty);
	}
	
	@Test (priority = 0, description = "Verifying heading of cart page")
	public void verifyHeading() {
		String heading = add.getText(add.heading);
		assertEquals(heading, prop.getProperty("CartPageTitle"));
	}
	
	@Test (priority = 1, description = "Remove product from cart")
	public void verifyRemoveFromCart() {
		add.clickElement(add.removeIcon);
		//assertTrue(add.getText(add.removedFromCartMsg).contains(prop.getProperty("RemovedFromCartMsg")));
		assertTrue(add.getText(add.removedFromCartMsg).contains(prop.getProperty("EmptyCart")), "Failed to remove product from cart!");
	}
	
	@Test (priority = 2, description = "Undo removal of product from cart")
	public void verifyUndoRemoval() throws InterruptedException {
		wait(5);
		add.clickElement(add.undo);
		assertTrue(add.isDisplayed(add.nameOfProductInCart), "Failed to undo removal from cart!");
	}
	
	@Test (priority = 3, description = "Update cart")
	public void verifyUpdateCart() throws InterruptedException {
		wait(3);
		add.sendText(prop.getProperty("UpdateCart"), add.quantity);
		add.clickElement(add.updateCartBtn);
		wait(3);
		assertEquals(add.getAttributeValue(add.quantity, prop.getProperty("CartPageAttributeForQuantity")), prop.getProperty("UpdateCart"));
	}
	
	@Test (priority = 4, description = "Checkout products from cart")
	public void verifyCheckout() throws InterruptedException {
		checkout = (CheckoutPage) add.clickElementAndReturnDriver(add.checkoutBtn, new CheckoutPage(driver));
		wait(5);
		assertEquals(checkout.getText(checkout.heading), prop.getProperty("Checkoutpage"));
	}
	
	@Test (priority = 5, description = "Placing an order without data")
	public void verifyPlaceOrderWithNoData() {
		order = (PlaceOrderPage) checkout.clickElementAndReturnDriver(checkout.placeOrderBtn, new PlaceOrderPage(driver));
		assertTrue(checkout.isDisplayed(checkout.errorMsg), "Error message not displayed for order without data!");
	}
	
	@Test (priority = 6, description = "Placing an order", dataProvider = "PlaceOrder", dataProviderClass = DataProviderUtility.class)
	public void verifyPlaceOrder(String type, String fname, String lname, String stAddr, String city, String state, String pincode, String phone, String email) throws InterruptedException {
		
		checkout.sendText(fname, checkout.firstName);
		checkout.sendText(lname, checkout.lastName);
		checkout.sendText(stAddr, checkout.streetAddress);
		//checkout.sendText(city, checkout.city);
		//checkout.selectBy(checkout.state, prop.getProperty("StateForOrdering"));
		checkout.sendText(pincode, checkout.pincode);
		checkout.sendText(phone, checkout.phone);
		checkout.sendText(email, checkout.email);
		checkout.clickElement(checkout.tandc);
		wait(3);
		checkout.clickElementAndReturnDriver(checkout.placeOrderBtn, new PlaceOrderPage(driver));
				
		if (type.equals("invalid")) {
			assertTrue(checkout.isDisplayed(checkout.errorMsg), "Error message not displayed for invalid order!");
		}
		else if (type.equals("valid")) {
			assertFalse(checkout.isDisplayed(checkout.placeOrderBtn), "Order not placed!");
		}
	}
	
	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit(); // QUIT THE WEBDRIVER INSTANCE
		}
	}


}
