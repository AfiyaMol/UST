package com.ust.Maples.stepdefinitions;

import static org.testng.Assert.assertTrue;

import java.util.Properties;

import org.openqa.selenium.WebDriver;

import com.ust.Maples.pages.SortByPage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

//AUTHOR: AAFIYA MOL S A

//--------------------SORT FUNCTIONALITY VALIDATION--------------------//

public class SortByPageTest {
	
	WebDriver driver = Hooks.driver;
	Properties prop = Hooks.prop;
	public SortByPage sort = new SortByPage(driver);
	
	@Given("I am in home page")
	public void i_am_in_home_page() {
		driver.get(prop.getProperty("BaseUrl"));
	}
	@And("I click products link")
	public void i_click_products_link() {
	    sort.clickElement(sort.productsLink);
	}
	@And("I am navigated to products page")
	public void i_am_navigated_to_shop_page() {
		 //sort.getHeadingText(sort.pageHeading);
		 assertTrue(sort.getHeadingText(sort.pageTitle).contains(prop.getProperty("Heading")));
	}
	@When("I click SortBy to select an option")
	public void i_click_sort_by_to_select_an_option() {
	   sort.clickElement(sort.sortby);
	}
	@Then("I validate the sortby results")
	public void i_validate_the_sortby_results() {
	   sort.dropDown(sort.sortby);
	   assertTrue(sort.getpageUrl(prop.getProperty("Shopurl")),"Failed to load page!");
	}
  
}
