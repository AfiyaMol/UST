package com.ust.Maples.tests;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Maples.base.Setup;
import com.ust.Maples.pages.ProductsPage;
import com.ust.Maples.testlistener.ExtentReportListener;


//AUTHOR: AAFIYA MOL S A

//--------------------PRODUCT PAGE VALIDATION--------------------//

@Listeners(ExtentReportListener.class)
public class ProductPageTest extends Setup {

	public WebDriver driver;
	public ProductsPage product;

	@BeforeClass
	public void setup() {
		driver = invokeBrowser(prop.getProperty("Browser"));
		product = new ProductsPage(driver);
		driver.get(prop.getProperty("BaseUrl"));
	}

	@Test
	public void verifyDropdown() {
		product.clickLinks(product.productLink);	
	}
	@Test
	public void verifyIcons() {
		
		product.clickIcons(product.chicken);
		assertTrue(product.getPageUrl(prop.getProperty("ChickenUrl")), "Failed to load searched page!");
	
	}
	
	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit(); // QUIT THE WEBDRIVER INSTANCE
		}
	}


}
