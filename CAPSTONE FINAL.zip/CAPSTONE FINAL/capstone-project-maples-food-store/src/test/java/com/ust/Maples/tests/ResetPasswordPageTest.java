package com.ust.Maples.tests;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Maples.base.Setup;
import com.ust.Maples.pages.HomePage;
import com.ust.Maples.pages.LoginPage;
import com.ust.Maples.pages.LostPasswordPage;
import com.ust.Maples.pages.ResetPasswordsPage;
import com.ust.Maples.testlistener.ExtentReportListener;


//AUTHOR: ARDRA A

//--------------------RESET PASSWORD FUNCTIONALITY VALIDATION--------------------//

@Listeners(ExtentReportListener.class)
public class ResetPasswordPageTest extends Setup {
	public WebDriver driver;
	public HomePage home;
	public LoginPage login;
	public ResetPasswordsPage resetpage;
	public LostPasswordPage lostpassword;

	@BeforeClass
	public void beforeClass() {
		driver=invokeBrowser(prop.getProperty("Browser"));
		home=new HomePage(driver);
		login=new LoginPage(driver);

		driver.get(prop.getProperty("BaseUrl"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(7));


	}
	@Test(priority=0 , description="Reset password with valid username or Email")
	public void verifyResetPassword()
	{
		home.clickElement(home.loginLink);
		resetpage=(ResetPasswordsPage) login.clickElementAndReturnDriver(login.lostPassword, new ResetPasswordsPage(driver));
		resetpage.insertTxt(resetpage.Uname,prop.getProperty("LostPasswordUsername"));
		lostpassword= (LostPasswordPage) resetpage.clickElementAndReturnDriver(resetpage.resetButton, new LostPasswordPage(driver));
		assertEquals(lostpassword.getText(lostpassword.lostPasswordText),prop.getProperty("LostPasswordText"));
	}
	@Test(priority=1 , description="Reset password with Invalid username or Email")
	public void verifyInvalidResetPassword()
	{
		home.clickElement(home.loginLink);
		resetpage=(ResetPasswordsPage) login.clickElementAndReturnDriver(login.lostPassword, new ResetPasswordsPage(driver));
		resetpage.insertTxt(resetpage.Uname,prop.getProperty("LostPasswordInvalidEmail"));
		lostpassword= (LostPasswordPage) resetpage.clickElementAndReturnDriver(resetpage.resetButton, new LostPasswordPage(driver));
		assertEquals(lostpassword.getText(lostpassword.lostPasswordText),prop.getProperty("LostPasswordTextEmail"));
	}
	@Test(priority=2 , description="Reset password with Invalid username or Email")
	public void verifyNullResetPassword()
	{
		home.clickElement(home.loginLink);
		resetpage=(ResetPasswordsPage) login.clickElementAndReturnDriver(login.lostPassword, new ResetPasswordsPage(driver));
		lostpassword= (LostPasswordPage) resetpage.clickElementAndReturnDriver(resetpage.resetButton, new LostPasswordPage(driver));
		assertEquals(lostpassword.getText(lostpassword.lostPasswordText),prop.getProperty("NullText"));
	}

	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit(); // QUIT THE WEBDRIVER INSTANCE
		}
	}

}
