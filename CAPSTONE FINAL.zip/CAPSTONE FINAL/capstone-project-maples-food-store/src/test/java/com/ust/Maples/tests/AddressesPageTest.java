package com.ust.Maples.tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Maples.base.Setup;
import com.ust.Maples.dataproviders.DataProviderUtility;
import com.ust.Maples.pages.AddressesPage;
import com.ust.Maples.pages.HomePage;
import com.ust.Maples.pages.LoginPage;
import com.ust.Maples.testlistener.ExtentReportListener;


//AUTHOR: AAFIYA MOL S A

//--------------------USER ADDRESS DETAILS VALIDATION--------------------//


@Listeners(ExtentReportListener.class)
public class AddressesPageTest extends Setup {
	public WebDriver driver;
	public AddressesPage address;
	public LoginPage login;
	public HomePage home;

	@BeforeClass
	public void setup() {
		driver = invokeBrowser(prop.getProperty("Browser"));		
		address = new AddressesPage(driver);
		login = new LoginPage(driver);
		home = new HomePage(driver);
		driver.get(prop.getProperty("BaseUrl"));
	}
	// USING DATAPROVIDER
	@Test (priority = 1, dataProvider = "AddressLogin", dataProviderClass = DataProviderUtility.class,description = "Login to my account")
	public void verifyLogin(String username, String password) throws InterruptedException{
		home.clickElement(home.loginLink);
		login.sendText(username, login.uname);
		login.sendText(password, login.pswd);
		login.clickButton(login.logButton);
	}
//
//	@Test (priority = 2, dataProvider = "BAddress", dataProviderClass = DataProviderUtility.class,description = "Login to my account")
//	public void billAddress(String addr, String city , String state, String pincode ,String phonenum ) throws InterruptedException {
//		address.clickElement(address.add);
//		address.clickElement(address.billingAdd);
////		address.sendText(firstname, address.fname);
////		address.sendText(lastname, address.lname);
//		address.sendText(addr, address.address);
//		address.sendText(city, address.city);
//		address.selectState(state);
//		address.sendText(pincode, address.pincode);
//		address.sendText(phonenum, address.phone);
//		address.clickElement(address.saveButton);
//		assertEquals(address.getText(address.addSuccessText), prop.getProperty("Billingadd"));
//
//	}
	@Test (priority = 3, dataProvider = "SAddress", dataProviderClass = DataProviderUtility.class,description = "Login to my account")
	public void shippingAddress(String sFirstname, String sLastname , String sAddr, String sCity , String sState, String postcode) throws InterruptedException{
		address.clickElement(address.add);
		address.clickElement(address.shippingAdd);
		address.sendText(sFirstname, address.shippingfname);
		address.sendText(sLastname, address.shippinglname);
		address.sendText(sAddr, address.shippingaddress);
		address.sendText(sCity, address.shippingcity);
		address.clickElement(address.shippingStateoption);
		address.sendText(sState, address.shippingstate);
		address.clickElement(address.shippingStateoption);
		address.sendText(postcode, address.shippingpostcode);
		
		address.clickElement(address.saveAddButton);
		//assertEquals(address.getText(address.shipSuccessText), prop.getProperty("Shippingadd"));
	}

//	@AfterClass
//	public void tearDown() {
//		if (driver != null) {
//			driver.quit(); // QUIT THE WEBDRIVER INSTANCE
//		}
//	}


}
