package com.ust.Maples.tests;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.Maples.base.Setup;
import com.ust.Maples.dataproviders.DataProviderUtility;
import com.ust.Maples.pages.AccountDetailsPage;
import com.ust.Maples.pages.HomePage;
import com.ust.Maples.pages.LoginPage;
import com.ust.Maples.testlistener.ExtentReportListener;


//AUTHOR: AAFIYA MOL S A

//--------------------USER ACCOUNT DETAILS VALIDATION--------------------//

@Listeners(ExtentReportListener.class)
public class AccountDetailsPageTest extends Setup {
	public WebDriver driver;
	public AccountDetailsPage acc;
	public LoginPage login;
	public HomePage home;
	
	@BeforeClass
	public void setup() {
		driver = invokeBrowser(prop.getProperty("Browser"));
		login = new LoginPage(driver);
		acc = new AccountDetailsPage(driver);
		home = new HomePage(driver);
		driver.get(prop.getProperty("BaseUrl"));
	}
	
	@Test (priority = 1, dataProvider = "AddressLogin", dataProviderClass = DataProviderUtility.class,description = "Login to my account")
	public void verifyLogin(String username, String password) throws InterruptedException{
		home.clickElement(home.loginLink);
		login.sendText(username, login.uname); 
		login.sendText(password, login.pswd);
		login.clickButton(login.logButton); 
	}
	
	@Test (priority = 2 ,dataProvider = "AccDetails", dataProviderClass = DataProviderUtility.class, description = "Account Details")
	public void verifysaveAccDetails(String fname, String lname) {
		acc.clickElement(acc.accDetailsLink);
		acc.sendText(fname, acc.fname);
		acc.sendText(lname, acc.lname);
		acc.clickElement(acc.saveButton);
		assertEquals(acc.getText(acc.successText), prop.getProperty("SuccAccDetails"));
	}
	
	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit(); // QUIT THE WEBDRIVER INSTANCE
		}
	}


	
}
