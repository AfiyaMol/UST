package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.ust.Maples.reusable.ReusableFunctions;

//AUTHOR: MARIYA ROY

public class CheckoutPage {

	public WebDriver driver;
	private ReusableFunctions reusableFunctions;

	public CheckoutPage(WebDriver driver) {
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver = driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this); // USING PAGE FACTORY
	}

	@FindBy (className = "entry-title")
	public WebElement heading;

	@FindBy (id = "place_order")
	public WebElement placeOrderBtn;

	@FindBy (css = "ul.woocommerce-error")
	public WebElement errorMsg;

	@FindBy (id = "billing_first_name")
	public WebElement firstName;

	@FindBy (id = "billing_last_name")
	public WebElement lastName;

	@FindBy (id = "billing_address_1")
	public WebElement streetAddress;

	@FindBy (id = "billing_city")
	public WebElement city;

	@FindBy (id = "billing_state")
	public WebElement state;

	@FindBy (id = "billing_postcode")
	public WebElement pincode;

	@FindBy (id = "billing_phone")
	public WebElement phone;

	@FindBy (id = "billing_email")
	public WebElement email;

	@FindBy (id = "terms")
	public WebElement tandc;

	public String getText(WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		return reusableFunctions.getTextString(el);
	}

	public void sendText(String text, WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		reusableFunctions.insertText(text, el);
	}

	public boolean isDisplayed(WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		return reusableFunctions.isDisplayed(el);
	}

	public void selectBy(WebElement el, String value) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		Select element = new Select(el); // USING SELECT CLASS FOR DROPDOWN
		element.selectByVisibleText(value);
	}

	public void clickElement(WebElement el)  {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		reusableFunctions.actionClick(el);
	}

	public Object clickElementAndReturnDriver(WebElement el, Object o)   {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		reusableFunctions.actionClick(el);
		return o;

	}

}
