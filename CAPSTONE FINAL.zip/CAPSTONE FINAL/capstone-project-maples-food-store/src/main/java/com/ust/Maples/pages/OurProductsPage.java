package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

// AUTHOR: MARIYA ROY

public class OurProductsPage {

	public WebDriver driver;
	public HomePage home;
	private ReusableFunctions reusableFunctions;

	public OurProductsPage(WebDriver driver) {
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver = driver;
		home = new HomePage(driver);
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this); // USING PAGE FACTORY
	}
	
	@FindBy (xpath = "//h1[contains(@class,'elementor-heading-title')]")
	public WebElement heading;

	public void clickLink(String link) {
		switch(link) {
		case "Chicken": home.clickElement(home.chickenFooterLink);
		break;
		case "Mutton": home.clickElement(home.muttonFooterLink);
		break;
		case "Pork": home.clickElement(home.porkFooterLink);
		break;
		case "Sea Food": home.clickElement(home.seafoodFooterLink);
		break;
		case "Chips & Dips": home.clickElement(home.chipsFooterLink);
		break;
		case "Dry Fruits, Nuts, Seeds & Berries": home.clickElement(home.dryfruitsFooterLink);
		break;
		case "Ice Creams": home.clickElement(home.icecreamsFooterLink);
		break;
		}
	}
	
	public String getText(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		return reusableFunctions.getTextString(el);
	}
	
	public String getUrl() {
		return reusableFunctions.getUrl();
	}

}
