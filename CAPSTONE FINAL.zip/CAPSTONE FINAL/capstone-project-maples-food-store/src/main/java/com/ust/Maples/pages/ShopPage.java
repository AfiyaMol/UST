package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

// AUTHOR: ARDRA A

public class ShopPage 
{
	public WebDriver driver;
	public ReusableFunctions reusableFunctions;
	
	public ShopPage(WebDriver driver)
	{
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver = driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this);
	}
	
	//@FindBy(xpath="//*[@id=\"woocommerce_product_categories-1\"]/ul/li[1]/a")
	@FindBy(linkText="Bakery")
	public WebElement categorySelect;
	
	//@FindBy(className="entry-title")
	@FindBy(xpath="//h1[contains(text(),'Bakery')]")
	public WebElement categoryName;
	
	
	//@FindBy(className="wcpf-title-container")
	@FindBy(xpath="//a[contains(text(),'chicken')]")
	public WebElement brands;
	
	//@FindBy(linkText="Healthy Brown Pizza Medium")
	@FindBy(xpath="//h1[contains(text(),'chicken')]")
	public WebElement brandsName;
	
	
	public String getText(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		return reusableFunctions.getTextString(el);
	}
	
	public void clickElement(WebElement el)  {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.actionClick(el);
	}
	
	
	
}
