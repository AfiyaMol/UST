package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

//AUTHOR: MARIYA ROY

public class MyAccountPage {
	
	public WebDriver driver;
	public ReusableFunctions reusableFunctions;
	
	public MyAccountPage(WebDriver driver) {
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver = driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this);
	}
	
	//@FindBy (css = "div.woocommerce-MyAccount-content > p:nth-of-type(2)")
	@FindBy (css = "div.woocommerce-MyAccount-content > div > p:nth-of-type(1)")
	public WebElement welcomeText;
	
	//@FindBy (css = "div.login-logout-links > a:nth-of-type(2)")
	@FindBy (css = "div.woocommerce-MyAccount-content > div > p:nth-of-type(1) > a")
	public WebElement logoutLink;
	
	public String getText(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		return reusableFunctions.getTextString(el);
	}
	
	public void clickElement(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.clickElement(el);
	}

}
