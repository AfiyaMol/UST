package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

//AUTHOR: MARIYA ROY

public class ProductDetailsPage {
	
	public WebDriver driver;
	private ReusableFunctions reusableFunctions;
	
	public ProductDetailsPage(WebDriver driver) {
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver = driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this); // USING PAGE FACTORY
	}
	
	@FindBy (name = "add-to-cart")
	public WebElement addToCartBtn;
	
	@FindBy (xpath = "(//a[@data-title='Add to wishlist'])[1]")
	public WebElement wishlistLink;
	
	@FindBy (xpath = "//a[@data-title='Browse wishlist']")
	public WebElement browseWishlist;
	
	@FindBy (css = "div.woocommerce-message > a.wc-forward")
	public WebElement viewCartBtn;
	
	public void clickElement(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.actionClick(el);
	}
	
	public Object clickElementAndReturnDriver(WebElement el, Object o) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.actionClick(el);
		return o;
	}

}
