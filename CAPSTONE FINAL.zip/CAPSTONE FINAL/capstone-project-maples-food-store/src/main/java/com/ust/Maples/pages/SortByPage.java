package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.ust.Maples.reusable.ReusableFunctions;

// AUTHOR: AAFIYA MOL S A

public class SortByPage {

	public WebDriver driver;
	private ReusableFunctions reusableFunctions;

	public SortByPage(WebDriver driver) {
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver = driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this);		
	}
	@FindBy (xpath = "//*[@id=\"menu-1-349711e\"]/li[3]/a")
	public WebElement productsLink;

	//@FindBy (xpath = "//div[@class='elementor-widget-container']")
	@FindBy (xpath = "//h1[@class='elementor-heading-title elementor-size-default']")
	public WebElement pageTitle;

	@FindBy (className = "orderby")
	public WebElement sortby;



	public boolean getpageUrl(String url) {
		return reusableFunctions.checkUrl(url);
	}

	public void clickElement(WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		reusableFunctions.actionClick(el);
	}

	public void dropDown(WebElement el) {	
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		Select sortChoice = new Select(sortby);
		sortChoice.selectByVisibleText("Sort by latest");
	}

	public String getHeadingText(WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		return reusableFunctions.getTextString(el);
	}

}
