package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

//AUTHOR: MARIYA ROY

public class SitemapResultPage {
	

	public WebDriver driver;
	private ReusableFunctions reusableFunctions;
	
	public SitemapResultPage(WebDriver driver) {
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver = driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this); // USING PAGE FACTORY
	}
	
	@FindBy (css = "p.elementor-heading-title")
	public WebElement title;
	
	public boolean isDisplayed(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		return reusableFunctions.isDisplayed(el);
	}
	
	public boolean getUrl(String url) {
		return reusableFunctions.checkUrl(url);
	}

}
