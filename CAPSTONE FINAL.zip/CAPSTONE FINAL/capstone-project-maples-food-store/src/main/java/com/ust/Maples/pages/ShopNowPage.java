package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.ust.Maples.reusable.ReusableFunctions;

// AUTHOR: ARDRA A

public class ShopNowPage {
	public WebDriver driver;
	private ReusableFunctions reusableFunctions;
	
	public ShopNowPage(WebDriver driver)
	{
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver=driver;
		reusableFunctions=new ReusableFunctions(driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div[1]/div/h1")
	public WebElement shopNowTitle;
	
	
	public String getText(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		return reusableFunctions.getTextString(el);
	}
	
	public boolean getUrl(String url) {
		return reusableFunctions.checkUrl(url);
	}
}







