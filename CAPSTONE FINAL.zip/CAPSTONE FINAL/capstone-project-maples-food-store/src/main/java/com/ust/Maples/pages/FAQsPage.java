package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

//AUTHOR: ARDRA A

public class FAQsPage 
{
	WebDriver driver;
	ReusableFunctions reusableFunctions;

	
	@FindBy(id="ui-id-1")
	public WebElement faqQuestion;
	
	@FindBy(id="ui-id-2")
	public WebElement faqAnswers;
	
	@FindBy(xpath="//h2[contains(text(),'FAQs')]")
	public WebElement faqText;

	public FAQsPage(WebDriver driver)
	{
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		
		this.driver = driver;
		PageFactory.initElements(driver, this);
		reusableFunctions = new ReusableFunctions(driver);
	}
	
	public boolean checkUrlFAQs(String url)
	{
		return reusableFunctions.checkUrl(url);
	}
	

	public String getTextFaq(WebElement el)
	{	
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		return reusableFunctions.getTextString(el);
	}

}
