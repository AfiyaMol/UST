package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

//AUTHOR: MARIYA ROY

public class HomePage {

	public WebDriver driver;
	private ReusableFunctions reusableFunctions;

	public HomePage(WebDriver driver) {
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver = driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this); // USING PAGE FACTORY
	}

	@FindBy (xpath = "(//div[@class='elementor-widget-container'])[4]//img")
	//@FindBy (xpath = "(//a[@title='Maples'])[1]")
	public WebElement logo;

	//@FindBy (xpath="//a[contains(text(),'Login')]")
	@FindBy (css = "div.elementor-element-c860ec7 >div > h5 > a")
	public WebElement loginLink;

	//@FindBy (css = "div.login-logout-links > a:nth-of-type(2)")
	@FindBy (css = "div.elementor-element-c860ec7 >div > h5 > a")
	public WebElement signUpLink;

	@FindBy (name = "s")
	public WebElement searchBar;

	@FindBy (xpath = "//button[contains(text(),'Search')]")
	public WebElement searchIcon;

	@FindBy (xpath = "(//div[@class = 'cart-toggler']/a)[1]")
	public WebElement navBarCartIcon;

	@FindBy (xpath = "(//span[@class='cart-quantity'])[1]")
	public WebElement navBarCartQty;

	@FindBy (xpath = "(//a[@class='button wc-forward'])[1]")
	public WebElement viewCartBtn;

	@FindBy (xpath = "(//div[@class = 'header-wishlist-inner']/a)[1]")
	public WebElement navBarWishlistIcon;

	@FindBy (xpath = "(//span[@class='wishlist-count header-count'])[1]")
	public WebElement navBarWishlistQty;

	//@FindBy (xpath = "(//div[@class='list-col4'])[2]//a")
	@FindBy (xpath = "(//a[contains(text(),'Venkys Chi Plain Keema 250gm')])[3]")
	public WebElement pdtAddedTocart;

	@FindBy (linkText = "Home")
	public WebElement homeLink;

	@FindBy (linkText = "About Us")
	public WebElement aboutUsLink;

	//@FindBy (xpath = "//*[@id=\"menu-item-4103\"]/a/span")	
	//@FindBy (linkText = "Products")
	@FindBy (xpath = "//ul[@id='menu-1-349711e']/li[3]/a")
	public WebElement productsLink;

	@FindBy (linkText = "Store Locator")
	public WebElement storeLocLink;

	//@FindBy (linkText = "Contact")
	//@FindBy (css = "li.menu-item-3414 > a#sm-1718865404973969-1")
	@FindBy (xpath = "(//li[contains(@class,'menu-item-3414')]/a)[1]")
	public WebElement contactLink;
	
	@FindBy (xpath = "//li[contains(@class,'menu-item-5817')]/a")
	public WebElement franchise;

	@FindBy (xpath = "//a[contains(text(),'View All')]")
	public WebElement viewAllBtn;

	//@FindBy (xpath = "(//a[contains(text(),'Shop Now')])[1]")
	@FindBy (xpath = "(//span[contains(text(),'Shop Now')])[1]")
	public WebElement shopNowBtn;

	@FindBy (linkText = "FAQs")
	public WebElement faqLink;

	@FindBy (id = "menu-item-4182")
	public WebElement shipRefundPolicyLink;

	@FindBy (linkText = "Privacy Policy")
	public WebElement privacyPolicyLink;

	@FindBy (linkText = "Terms and Conditions")
	public WebElement tandcLink;

	@FindBy (linkText = "Sitemap")
	public WebElement sitemapLink;

	@FindBy (xpath = "//div[@data-id='1d643c9']/div/p")
	//@FindBy (css = "div.txt-copyright > div > p")
	public WebElement copyRight;

	@FindBy (xpath = "//div[@data-id='6206d11']//li[1]")
	public WebElement chickenFooterLink;

	@FindBy (xpath = "//div[@data-id='6206d11']//li[2]")
	public WebElement muttonFooterLink;

	@FindBy (xpath = "//div[@data-id='6206d11']//li[3]")
	public WebElement porkFooterLink;

	@FindBy (xpath = "//div[@data-id='6206d11']//li[4]")
	public WebElement seafoodFooterLink;

	@FindBy (xpath = "//div[@data-id='6206d11']//li[5]")
	public WebElement chipsFooterLink;

	@FindBy (xpath = "//div[@data-id='6206d11']//li[6]")
	public WebElement dryfruitsFooterLink;

	@FindBy (xpath = "//div[@data-id='6206d11']//li[7]")
	public WebElement icecreamsFooterLink;	

	public boolean getUrl(String url) {
		return reusableFunctions.checkUrl(url);
	}

	public boolean getTitle(String title) {
		return reusableFunctions.checkTitle(title);
	}

	public boolean isDisplayed(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		return reusableFunctions.isDisplayed(el);
	}

	public String getText(WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		return reusableFunctions.getTextString(el);
	}


	public void sendText(String text, WebElement el) {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.insertText(text, el);
	}

	public void clickElement(WebElement el)  {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.actionClick(el);
	}

	public Object clickElementAndReturnDriver(WebElement el, Object o)   {
		if (el == null) {
	        throw new NullPointerException("WebElement is null");
	    }
		reusableFunctions.actionClick(el);
		return o;

	}
	
	
	
}