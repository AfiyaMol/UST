package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

// AUTHOR: AAFIYA MOL S A

public class AccountDetailsPage {
	public WebDriver driver;
	private ReusableFunctions reusableFunctions;

	public AccountDetailsPage(WebDriver driver) {
		if (driver == null) {
			throw new NullPointerException("WebDriver instance is null");
		}
		this.driver = driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this);
	}

	@FindBy(linkText = "Account Details")
	public WebElement accDetailsLink;

	@FindBy (id = "account_first_name")
	public WebElement fname;

	@FindBy (id = "account_last_name")
	public WebElement lname;

	@FindBy (name = "save_account_details")
	public WebElement saveButton;

	@FindBy (xpath = "//li[@data-id='account_first_name']")
	public WebElement fnameError;

	@FindBy (xpath = "//li[@data-id='account_last_name']")
	public WebElement lnameError;

	@FindBy (xpath = "//div[@class='woocommerce-message']")
	public WebElement successText;
	@FindBy (className = "woocommerce-message")
	public WebElement successsText;

	public String getText(WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		return reusableFunctions.getTextString(el);
	}

	public void sendText(String text, WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		reusableFunctions.insertText(text, el);
	}

	public void clickElement(WebElement el)  {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		reusableFunctions.actionClick(el);
	}

}
