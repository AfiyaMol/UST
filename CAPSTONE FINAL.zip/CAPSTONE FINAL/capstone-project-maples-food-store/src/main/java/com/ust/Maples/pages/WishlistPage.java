package com.ust.Maples.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.Maples.reusable.ReusableFunctions;

//AUTHOR: MARIYA ROY

public class WishlistPage {

	public WebDriver driver;
	private ReusableFunctions reusableFunctions;

	public WishlistPage(WebDriver driver) {
	    if (driver == null) {
	        throw new NullPointerException("WebDriver instance is null");
	    }

		this.driver = driver;
		reusableFunctions = new ReusableFunctions(driver);
		PageFactory.initElements(driver, this); // USING PAGE FACTORY
	}

	@FindBy (className = "entry-title")
	public WebElement heading;

	@FindBy (xpath = "(//td[@class='product-remove'])[1]//a")
	public WebElement removeIcon;

	@FindBy (className = "wishlist-empty")
	public WebElement emptyWishlistMsg;

	public String getText(WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		return reusableFunctions.getTextString(el);
	}

	public void clickElement(WebElement el) {
		if (el == null) {
			throw new NullPointerException("WebElement is null");
		}
		reusableFunctions.actionClick(el);
	}

	public boolean isDisplayed(WebElement el) {
		return reusableFunctions.isDisplayed(el);
	}

}
