package com.ust.java;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.ust.javaexamples.AlternateCharacters;

class AlternateCharactersTest {
	AlternateCharacters ac= new AlternateCharacters();
	@Test
	void testAlternateCharactersTest() {
		String input="afimol";
		String output="aio";
	
		assertEquals(output, AlternateCharacters.getAlternateCharacters(input));
		}
	
	@Test
	void testAlternateCharactersTest1() {
		String input="";
		String output="";
	
		assertEquals(output, AlternateCharacters.getAlternateCharacters(input));
		}

}
