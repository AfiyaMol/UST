package com.ust.javaexamples;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class UsernameTest {

	@Test
	void testUsername() {
		String input="aafi@123.com";
		String output="aafi";
		assertEquals(output, Username.fetch(input));
	}
	@Test
	void testUsername1() {
		String input="aafi123.com";
		String output="null";
		assertEquals(output, Username.fetch(input));
	}

}
