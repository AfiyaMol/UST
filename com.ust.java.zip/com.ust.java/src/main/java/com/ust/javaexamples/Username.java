package com.ust.javaexamples;

import java.util.Scanner;

public class Username {

	public static void main(String[] args) {
		Scanner scn =new Scanner(System.in);
		System.out.println("enter email");
		String S =scn.nextLine();
		System.out.println(fetch(S));
	}	
		
		public static String fetch(String S) {
	//String S= "aafiya@123.com";
	String newS=S.substring(0,S.indexOf('@'));
		if(S.indexOf ('@') == -1)  return "null";
		else return newS;

	}

}
//public class Username {
//    public static void main(String[] args) {
//        String S = "aafiya@123.com";
//        int atIndex = S.indexOf('@'); // Find the index of '@'
//
//        if (atIndex != -1) { // Check if '@' exists in the string
//            StringBuilder newS = new StringBuilder();
//            newS.append(S, 0, atIndex); // Append characters up to '@'
//            System.out.println(newS.toString());
//        } else {
//            System.out.println("Invalid input: '@' not found.");
//        }
//    }
//}
