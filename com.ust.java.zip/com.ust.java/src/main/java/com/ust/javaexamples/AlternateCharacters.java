package com.ust.javaexamples;

import java.util.Scanner;

public class AlternateCharacters {
	 
	public static String getAlternateCharacters(String str) {
	
		StringBuilder sent = new StringBuilder(); 
        for (int i=0 ; i < str.length() ;i= i+2) {
        	
        	sent.append(str.charAt(i));
        		
        	}return sent.toString();
        }
	

	public static void main(String[] args) {
		Scanner scn =new Scanner(System.in);
		System.out.println("enter a string");
		String str= scn.nextLine();
		String res=getAlternateCharacters(str);
		System.out.println(res);
	}
}
