package com.ust.javaexamples;
//to get the index of all the characters of the alphabet.
public class GetIndexOfAll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="The quick brown fox jumps over the lazy dog";
		String alphabtes="abcdefghijklmnopqrstuvwxyz";
		
		for(char ch : alphabtes.toCharArray()) {
			 int index = s.indexOf(ch);
			
		System.out.println(index);
	}
	}
}
