package com.ust.javaexamples;
//to get the character at the given index within the string.
public class GetCharacters {
	
	
	public static void main(String[] args) {
		String s="Java Exercise";
		char str=s.charAt(0);
		char str2=s.charAt(10);
		
		
		System.out.println("At index 0 we have :" +str);
		System.out.println("At index 10 we have :" +str2);
	}

}
