package com.ust.javaexamples;

public class StringImmutableExample {
	public static void main(String[] args)
	{
		 String names[] = {"Hello","mohan","jayabalan"};
		 StringImmutableExample obj = new StringImmutableExample();
		 obj.joinWords(names);
		
	}
	private void joinWords(String[] names) {
//	{
//		String sent=" ";
//		for(int i =0; i < names.length; i++)
//			sent += names[i];
//		System.out.println(sent);
		StringBuilder sent = new StringBuilder(); // Initialize a StringBuilder
        for (String name : names) {
            sent.append(name); // Append each name to the StringBuilder
        }
        System.out.println(sent); // C
	} 


}
