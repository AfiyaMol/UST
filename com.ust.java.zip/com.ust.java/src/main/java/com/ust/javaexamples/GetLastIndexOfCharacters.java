package com.ust.javaexamples;

public class GetLastIndexOfCharacters {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="The quick brown fox jumps over the lazy dogyyyyyyyyyyyyyyaaa";
		String alphabtes="abcdefghijklmnopqrstuvwxyz";
		
		for(char ch : alphabtes.toCharArray()) {
			 int index = s.lastIndexOf(ch);
			
		System.out.print(index +" ");
	}
	}
}
