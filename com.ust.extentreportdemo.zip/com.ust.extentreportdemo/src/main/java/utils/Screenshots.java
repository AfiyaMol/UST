package utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

public class Screenshots {
	
		private int screenShotNumber =0;
		public void takeScreenShot(WebDriver driver,ExtentTest test) throws IOException {
			  File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			  File dest = new File("Extent Report/screenshot("+screenShotNumber+").png");
			  FileUtils.copyFile(screenshotFile, dest);
			  test.addScreenCaptureFromPath("screenshot("+screenShotNumber+").png");
			  screenShotNumber++;
	 
		}
	 
	}


