package reportimplementation;
import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import utils.Screenshots;
//OrangeHRM
public class ReportGeneration {
	WebDriver driver;
	ExtentReports report;
	ExtentSparkReporter spark;
	//TakesScreenshot screenshot;
	Screenshots ss;

	@Test(priority = 1)
	public void verifyUrl() {
		ExtentTest t= report.createTest("Verifying URL");
		String acturl=driver.getCurrentUrl();
		String expurl= "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
		System.out.println(acturl);
		try { 
			assertEquals(acturl, expurl);
			t.log(Status.PASS, "Verfied URL..Testcase Passed...");
			t.assignAuthor("afiya").assignDevice("Windows").assignDevice("Chrome");
		}catch(AssertionError e){
			t.log(Status.FAIL, "Verfied URL..Testcase Failed...");
			t.assignAuthor("afiya").assignDevice("Windows").assignDevice("Chrome");
		}
		//assertEquals(acturl, expurl);
		//		  if(expurl.equals(driver.getCurrentUrl()))
		//		  {
		//			  t.log(Status.PASS, "Verfied URL..Testcase Passed...");
		//			  t.assignAuthor("afiya").assignDevice("Windows").assignDevice("Chrome");
		//		  }
		//		  else
		//		  {
		//			  t.log(Status.FAIL, "Verfied URL..Testcase Failed...");
		//			  t.assignAuthor("afiya").assignDevice("Windows").assignDevice("Chrome");
		//		  } 

	}
	@Test(priority = 2)
	public void verifyTitle() throws InterruptedException {
		ExtentTest t= report.createTest("Verifying Title");
		String exTitle = "OrangeHRM";
		String title = driver.getTitle();
		System.out.println(title);
		try { 
			assertEquals(title,"OrangeHRM");
			t.log(Status.PASS, "Verfied Title..Testcase Passed...");
			t.assignAuthor("afiya").assignDevice("Windows").assignDevice("Chrome");
		}catch(AssertionError e) {
			t.log(Status.FAIL, "Verfied Title..Testcase Failed...");
			t.assignAuthor("afiya").assignDevice("Windows").assignDevice("Chrome");
		}
		//		  assertEquals(title,"OrangeHRM");
		//		  if(exTitle.equals(driver.getTitle()))
		//		  {
		//			  t.log(Status.PASS, "Verfied Title..Testcase Passed...");
		//			  t.assignAuthor("afiya").assignDevice("Windows").assignDevice("Chrome");
		//		  }
		//		  else
		//		  {
		//			  t.log(Status.FAIL, "Verfied Title..Testcase Failed...");
		//			  t.assignAuthor("afiya").assignDevice("Windows").assignDevice("Chrome");
		//		  } 


		//			private int screenShotNumber =0;
		//			public void takeScreenShot(WebDriver driver,ExtentTest test) throws IOException {
		//				  File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		//				  File dest = new File("ExtentReport/screenshot("+screenShotNumber+").png");
		//				  FileUtils.copyFile(screenshotFile, dest);
		//				  test.addScreenCaptureFromPath("screenshot("+screenShotNumber+").png");
		//				  screenShotNumber++;
		//		 


	}
	@Test(priority = 3, enabled = false)
	public void verifyLogin() throws InterruptedException, IOException {
		ExtentTest t= report.createTest("Verifying Login");
		Thread.sleep(7000);
		driver.findElement(By.name("username")).sendKeys("Admin");
		Thread.sleep(1000);
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//div[3]/button")).click();
		Thread.sleep(4000);
		
	}
	
	@Test(priority = 3)
	public void verifyLoginInvalid() throws InterruptedException, IOException {
		ExtentTest t= report.createTest("Verifying Login");
		Thread.sleep(7000);
		driver.findElement(By.name("username")).sendKeys("Admin");
		Thread.sleep(1000);
		driver.findElement(By.name("password")).sendKeys("admin12");
		driver.findElement(By.xpath("//div[3]/button")).click();
		Thread.sleep(4000);
		String errMsg = "Invalid credentials";
		String actMsg = driver.findElement(By.xpath("//div[1]/p")).getText();
		System.out.println(actMsg);
		try {
			assertEquals(actMsg, errMsg );
			
			//File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			//File dest = new File("Screenshots/screenshot.png");
			//FileUtils.copyFile(screenshotFile, dest); // Add dependency in pom.xml
			
			t.log(Status.PASS, "Login Successfully");
			t.assignAuthor("Afiya").assignDevice("Windows");
			//t.addScreenCaptureFromPath("screenshot.png"); // Adding screenshot to the report

		}catch(AssertionError e){
		t.log(Status.FAIL, "Unsuccessful Login");
		ss.takeScreenShot(driver, t);
			t.assignAuthor("Afiya").assignDevice("Windows");	
		}
		
	}
	@Test(priority = 4, enabled = false)
	public void verifyDashboard() throws InterruptedException, IOException {
		ExtentTest t= report.createTest("Verifying Dashboard");
		String expectedText = "Dashboard";
		String actualText =driver.findElement(By.xpath("//div[1]/span/h6")).getText();
		System.out.println(actualText);
		
		try {
			assertEquals(actualText, expectedText);
			// Take screenshot
			File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			File dest = new File("Screenshots/screenshot.png");
			FileUtils.copyFile(screenshotFile, dest); // Add dependency in pom.xml
 
			t.log(Status.PASS, "Dashboard Successfully");
			t.assignAuthor("Afiya").assignDevice("Windows");
			t.addScreenCaptureFromPath("screenshot.png"); // Adding screenshot to the report
		}
		catch(AssertionError e) {
			t.log(Status.FAIL, "Unsuccessful Dashboard");
			t.assignAuthor("Afiya").assignDevice("Windows");	
		}
	}  
	@BeforeTest
	public void beforeTest() {
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com");
		report = new ExtentReports();
		spark = new ExtentSparkReporter("Extent Report/login.html");
		report.attachReporter(spark); 
		ss = new Screenshots();

	}

	@AfterTest
	public void afterTest() {
		report.flush();
	}
}
