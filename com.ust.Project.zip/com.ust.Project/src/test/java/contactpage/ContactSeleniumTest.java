package contactpage;

import static org.testng.Assert.assertEquals;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.ust.Assignment.browsers.Browser;

public class ContactSeleniumTest {

 
  static WebDriver driver;
	 static	Browser br;
		
		@Test
		public void launchBrowser() throws InterruptedException{
			br= new Browser();
			Scanner scn = new Scanner(System.in);
			System.out.println("select any one 1chrome 2edge)");
			String browser= scn.nextLine().toLowerCase();
			
			switch (browser) {
			case "1":
				driver = br.launch_Chrome();
				break;
			case "2":
				driver = br.launch_Edge();
				break;
			}
			//launch browser
		String expUrl="file:///C:/Users/272317/Downloads/ContactPage.html";
		driver.get(expUrl);
		String actUrl=driver.getCurrentUrl();
		assertEquals(expUrl,actUrl);
		System.out.println("Browser launched successfully");
		//radio button -male or female
		driver.findElement(By.xpath("/html/body/form/input[1]")).click();
		driver.findElement(By.xpath("/html/body/form/input[2]")).click();
		
		//username and password
		driver.findElement(By.id("fname")).clear();
		Thread.sleep(500);
		driver.findElement(By.id("fname")).sendKeys("aafiya");
		driver.findElement(By.id("lname")).clear();
		Thread.sleep(500);
		driver.findElement(By.id("lname")).sendKeys("mol");
		driver.findElement(By.xpath("/html/body/form/input[5]")).click();
		driver.findElement(By.xpath("/html/body/form/input[6]")).click();
		Thread.sleep(500);
		driver.navigate().to(actUrl);
		}
}
