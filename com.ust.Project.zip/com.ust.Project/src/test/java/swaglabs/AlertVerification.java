package swaglabs;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.ust.Assignment.browsers.Browser;

public class AlertVerification {
	WebDriver driver;
	Browser br;
	
	@Test
	public void alertVerify() throws InterruptedException{
		br= new Browser();
		driver = new ChromeDriver();
		
		driver.get("https://demoqa.com/alerts");
		System.out.println("website launched");
		//SimpleAlert=Button to see alert
		driver.findElement(By.id("alertButton")).click();
		Alert alert= driver.switchTo().alert();
		Thread.sleep(2000);
		alert.accept();
		System.out.println("Simple alert success");
		//alert will appear after 5 seconds
		driver.findElement(By.xpath("//*[@id=\"timerAlertButton\"]")).click();
		Thread.sleep(8000);
		alert.accept();
		System.out.println("Simple alert2 success");
		//Thread.sleep(3000);
		// ConfirmationAlert=confirm box will appearYou selected ok
		driver.findElement(By.id("confirmButton")).click();
		Thread.sleep(1000);
		alert.accept();
		System.out.println("Confirmation alert success");
	//	PromptAlert=prompt box will appear
		driver.findElement(By.xpath("//*[@id=\"promtButton\"]")).click();
		Thread.sleep(2000);
		alert.sendKeys("Aafi");
		Thread.sleep(1000);
//		
		alert.accept();
		System.out.println("prompt alert success");
//		
		
		
	}
	

}