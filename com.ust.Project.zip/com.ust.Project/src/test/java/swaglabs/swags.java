package swaglabs;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.ust.Assignment.browsers.Browser;

public class swags {
	
	static WebDriver driver;
	static Browser obj;
		@Test
		public void verify() throws InterruptedException {
			obj = new Browser();
			
			Scanner scn = new Scanner(System.in);
			System.out.println("select any one 1.chrome or 2.edge)-");
			String browser= scn.nextLine().toLowerCase();
			
			switch (browser) {
			case "1":
				driver = obj.launch_Chrome();
				break;
			case "2" :
				driver = obj.launch_Edge();
				break;
			}
			//lauching browser
			String expURL="https://www.saucedemo.com/";
			driver.get("https://www.saucedemo.com/");
			String actURL=driver.getCurrentUrl();
			//if(actURL.equals("https://www.saucedemo.com/"));
			assertEquals(actURL,expURL);
			scn.close();
			//to get title of web page
			String text=driver.getTitle();
			System.out.println(text);
			//validating login
			driver.findElement(By.id("user-name")).sendKeys("standard_user");	
			driver.findElement(By.id("password")).sendKeys("secret_sauce");	
			driver.findElement(By.id("login-button")).click();
			Thread.sleep(1000);
			//driver.navigate().to(actURL);
			//add to cart
			driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
			Thread.sleep(1000);
			//driver.findElement(By.xpath("//*[@id=\"react-burger-menu-btn\"]")).click();
			//Thread.sleep(2000);
			//driver.findElement(By.id("logout_sidebar_link")).click();
			
			//shoppingCart
			driver.findElement(By.className("shopping_cart_link")).click();
			driver.findElement(By.id("checkout")).click();
			driver.findElement(By.id("first-name")).sendKeys("aafiya");
			driver.findElement(By.id("last-name")).sendKeys("aafi123");
			driver.findElement(By.id("postal-code")).sendKeys("678004");
			driver.findElement(By.id("continue")).click();
			Thread.sleep(1000);
			//payment information
			String payInfo=driver.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[2]")).getText();
			Pattern p=Pattern.compile("SauceCard #[0-9]*");
			Matcher m=p.matcher(payInfo);
			if(m.matches()) System.out.println("valid");
			else System.out.println("invalid");
			
		
			driver.findElement(By.id("finish")).click();
			//successfull message validation
			String expMsg= "Thank you for your order!";
			String actMsg=driver.findElement(By.xpath("//*[@id=\"checkout_complete_container\"]/h2")).getText();
			assertEquals(expMsg,actMsg);
			System.out.println("successful message displayed");
			driver.navigate().to(actURL);
			Thread.sleep(2000);
			
			//error message validation
			driver.findElement(By.id("user-name")).sendKeys("standard_user");	
			driver.findElement(By.id("password")).sendKeys("secretsauce");	
			driver.findElement(By.id("login-button")).click();
			
			String expErrorMsg= "Epic sadface: Username and password do not match any user in this service";
			String actErrorMsg=driver.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/div[3]/h3")).getText();
			assertEquals(expErrorMsg,actErrorMsg);
			System.out.println("Error message displayed");
			
			
	}
		

}
