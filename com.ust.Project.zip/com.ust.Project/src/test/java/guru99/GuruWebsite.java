package guru99;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.ust.Assignment.browsers.Browser;

@Test
public class GuruWebsite {
	
WebDriver driver;
Browser obj=new Browser();
public void print() throws InterruptedException {
	driver= new EdgeDriver();
	driver.get("https://demo.guru99.com/test/ajax.html");
	driver.manage().window().maximize();
	String title= driver.getTitle();
	System.out.println(title);
	List<WebElement> radios = driver.findElements(By.name("name"));
	for(int i = 0; i<radios.size(); i++){
	    radios.get(i).click(); 
	    System.out.println(radios.get(i).getAttribute("value"));

	}
	driver.findElement(By.xpath("//*[@id=\"navbar-brand-centered\"]/ul/li[3]")).click();
	Thread.sleep(1000);
   //driver.findElement(By.xpath("//*[@id="dismiss-button"]/div/svg/path[1]")).click();
	driver.get("https://demo.guru99.com/Agile_Project/Agi_V1/");
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/input")).sendKeys("1303");
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/input")).sendKeys("Guru99");
	driver.findElement(By.name("btnLogin")).click();
	driver.findElement(By.xpath("/html/body/div[3]/div/ul/li[2]/a")).click();
	driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[6]/td[2]/select")).click();
//	
	Select dropDown = new Select(driver.findElement(By.name("accountno")));
	List<WebElement> drop = driver.findElements(By.tagName("option"));
	for(int i = 0; i< drop.size(); i++){
		dropDown.selectByVisibleText(drop.get(i).getText());
		 Thread.sleep(3000);
	}
	driver.findElement(By.name("AccSubmit")).click();
	 Thread.sleep(3000);
	driver.navigate().back();
	driver.findElement(By.xpath("/html/body/div[3]/div/ul/li[3]/a")).click();
}
}