package guru99;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.ust.Assignment.browsers.Browser;
@Test
public class GuruLogin {
	WebDriver driver;
	 public void login() throws InterruptedException{
		 Browser obj=new Browser();
		 driver=new ChromeDriver();
		 driver.get("https://demo.guru99.com/Agile_Project/Agi_V1/");
	
	driver.findElement(By.xpath("//*[@id=\"navbar-brand-centered\"]/ul/li[3]")).click();
	Thread.sleep(1000);
	//driver.findElement(By.xpath("//*[@id=\"dismiss-button\"]/div/svg")).click();
	

	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[1]/td[2]/input")).sendKeys("1303");
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/input")).sendKeys("Guru99");
	System.out.println("login ok");
}
}
