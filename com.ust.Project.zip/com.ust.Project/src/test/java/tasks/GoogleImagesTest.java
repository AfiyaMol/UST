
package tasks;

import org.testng.annotations.Test;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleImagesTest {

		
	  @Test
	  public void testImagesLink() throws InterruptedException {
		  
		  WebDriver driver = new ChromeDriver();
		  driver.get("https://google.com");
		  driver.findElement(By.linkText("Images")).click();
		  Thread.sleep(1000);
		  assertTrue(driver.findElement(By.xpath("//body/div[1]/div[2]/div/img")).isDisplayed());
		  driver.close();
		  
	  }
	}

