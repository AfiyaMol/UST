package tasks;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

	@Test
	public class Ebay {
	WebDriver driver;
	@BeforeTest
	public void check() {
		driver= new ChromeDriver();
		driver.get("https://www.ebay.com/");
		driver.manage().window().maximize();
}
	@Test
	public void verify() {
	driver.findElement(By.xpath("//*[@id=\"gh-ac\"]")).sendKeys("Selenium");
	driver.findElement(By.id("gh-btn")).click();
	System.out.println("Search Page is displayed");
	driver.findElement(By.linkText("Buy It Now")).click();
	System.out.println("Buy it now is clicked");
	driver.findElements(By.className("btn__cell")).get(3).click();
	System.out.println("Success");
    driver.findElement(By.linkText("Time: newly listed")).click();
    WebElement element = driver
			.findElement(By.xpath("//*[@id=\"item4e170f9204\"]/div/div[2]/div[2]/div[3]/span[1]/span/span"));
	assertEquals(true, element.getText().contains("May"));
	}
	@AfterTest
	public void last() {
	   // driver.quit();
	}
}
