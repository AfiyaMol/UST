package tasks;

import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Ust {
	 WebDriver driver;
	
	  @BeforeClass
	  public void first() {
		  driver = new ChromeDriver();
		  driver.manage().window().maximize();
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	  }
		
	  @Test
	  public void linkVerify() {
		  driver.get(" https://www.ust.com");
		  driver.findElement(By.xpath("//a[@href='/en/thinking-ahead']")).click();
		  assertTrue(driver.getCurrentUrl().equals("https://www.ust.com/en/thinking-ahead"));
	  }
	  
	  @AfterClass
	  public void last(){
		  driver.close();
	  }
	  

}
