package tasks;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

@Test
public class Gurantors {
WebDriver driver;
	public void validate() {
		
	driver=new ChromeDriver();
	driver.get("https://theguarantors.com/login");
	driver.findElement(By.id("username")).sendKeys("aafi@123");
	driver.findElement(By.id("password")).sendKeys("a@123");
	driver.findElement(By.name("action")).click();
	
	String expErrorMsg="Wrong email or password";
	String actErrorMsg=driver.findElement(By.id("error-element-password")).getText();
	System.out.println(actErrorMsg);
	assertEquals(expErrorMsg, actErrorMsg);
}
}