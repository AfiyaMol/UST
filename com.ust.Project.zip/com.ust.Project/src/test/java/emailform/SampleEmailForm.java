package emailform;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.ust.Assignment.browsers.Browser;

public class SampleEmailForm {
	WebDriver driver;
	Browser br;
	@Test
	public void verifyForm() throws InterruptedException{
		br=new Browser();
		driver= new ChromeDriver();
		driver.get("https://www.mycontactform.com/samples.php");
		String title= driver.getTitle();
		System.out.println(title);
		//click all the checkbox 
		List <WebElement> select= driver.findElements(By.name("email_to[]"));
		for(int i = 0; i< select.size(); i++){
			select.get(i).click();
		}
		driver.findElement(By.id("subject")).sendKeys("English" +Keys.TAB);
		driver.findElement(By.id("email")).sendKeys("aafi@gmail.com" +Keys.TAB);
		driver.findElement(By.id("q1")).sendKeys("English is good" +Keys.TAB);
		driver.findElement(By.id("q2")).sendKeys("English is always good");
		Thread.sleep(20000);
		driver.findElement(By.xpath("//*[@id=\"q3\"]")).click();
		
		driver.findElement(By.xpath("//*[@id=\"q4\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"q5\"]")).click();
		Thread.sleep(20000);
		List <WebElement> hi= driver.findElements(By.name("checkbox6[]"));
		for(int i = 0; i< hi.size(); i++){
			hi.get(i).click();
		}
		driver.findElement(By.id("q7")).sendKeys("05-07-2024");
		driver.findElement(By.id("q8")).sendKeys("ME");
		driver.findElement(By.id("q9")).sendKeys("india");
		driver.findElement(By.id("q10")).sendKeys("British Columbia");
		driver.findElement(By.name("q11_first")).sendKeys("aafiya");
		driver.findElement(By.name("q11_last")).sendKeys("mol");
		
		//click dropdown button
		Select month = new Select(driver.findElement(By.name("q12_month")));
		month.selectByVisibleText("2");
		 
		Select day = new Select(driver.findElement(By.name("q12_day")));
		day.selectByVisibleText("25");
		
		Select year = new Select(driver.findElement(By.name("q12_year")));
		year.selectByVisibleText("2000");
		
		driver.findElement(By.name("q12_year")).sendKeys("2000");
		//attach file
		driver.findElement(By.xpath("//*[@id=\"attach4589\"]")).sendKeys("C:\\Users\\272317\\Downloads\\ContactForm.txt");
		Thread.sleep(10000);
		List <WebElement> link=driver.findElements(By.tagName("a"));
		System.out.println(link.size());
		driver.findElement(By.name("submit")).click();
		//driver.findElement(By.linkText("Back to Form")).click();			 
		}
	}


