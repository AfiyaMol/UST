package classwork;

import static org.testng.Assert.assertEquals;

import java.util.Scanner;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.ust.Assignment.browsers.Browser;

public class HealthProof {
	 static WebDriver driver;
	 static	Browser br;

	@Test
	public void validate() throws InterruptedException{
		br= new Browser();
		Scanner scn = new Scanner(System.in);
		System.out.println("select any one 1chrome 2edge)");
		String browser= scn.nextLine().toLowerCase();
		
		switch (browser) {
		case "1":
			driver = br.launch_Chrome();
			break;
		case "2":
			driver = br.launch_Edge();
			break;
		}
		String expUrl="https://www.justdial.com/jdmart";
		driver.get(expUrl);
		String actUrl=driver.getCurrentUrl();
		assertEquals(actUrl,expUrl);
	
	driver.findElement(By.xpath("//*[@id=\"__next\"]/div/section[1]/div/header/div/div[3]/div/ul/li[4]/span/span[2]")).click();
	driver.findElement(By.xpath("//*[@id=\"__next\"]/div/section[1]/div/div/section[1]/div/div[2]/ul/li[1]/input")).sendKeys("aafi");
	driver.findElement(By.xpath("//*[@id=\"__next\"]/div/section[1]/div/div/section[1]/div/div[2]/ul/li[2]/input")).sendKeys("9354567810");
	driver.findElement(By.xpath("//*[@id=\"__next\"]/div/section[1]/div/div/section[1]/div/div[2]/div[1]/div[2]/button")).click();
	}
}
