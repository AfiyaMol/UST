package com.ust.ProjectSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class VerifyLandingPage {
	public static void main(String[] args) throws InterruptedException
	{
		String path = "C:\\Users\\272317\\JavaProject\\com.ust.Project\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/v1/index.html");
		Thread.sleep(4000);
		driver.get("https://petstore.octoperf.com/");
		Thread.sleep(4000);
		String title = driver.getTitle();
		System.out.println(title);
		String text = driver.findElement(By.linkText("Enter the Store")).getText();
		System.out.println(text);
		driver.quit();
		}
}
