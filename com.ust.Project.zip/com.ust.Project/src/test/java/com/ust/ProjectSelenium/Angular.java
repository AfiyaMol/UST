package com.ust.ProjectSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Angular {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver= new EdgeDriver();
		driver.get("https://angular-university.io/");
		String s=driver.getTitle();
		System.out.println(s);
		driver.findElement(By.className("register")).click();
		

	}

}
