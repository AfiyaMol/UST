package newproject;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Scanner;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ust.Assignment.browsers.Browser;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class VerifyLandingPage {

	static WebDriver driver;
	static Browser obj;
		
	@Test
	@Order(1)
	public void verify() throws InterruptedException {
		obj = new Browser();
		
		Scanner scn = new Scanner(System.in);
		System.out.println("select any one (chrome/edge)-");
		String browser= scn.nextLine().toLowerCase();
		
		switch (browser) {
		case "chrome":
			driver = obj.launch_Chrome();
			break;
		case "edge" :
			driver = obj.launch_Edge();
			break;
		}
		
		String expURL="https://www.saucedemo.com/";
		driver.get("https://www.saucedemo.com/");
		String actURL=driver.getCurrentUrl();
		//if(actURL.equals("https://www.saucedemo.com/"));
		assertEquals(actURL,expURL);
		
		scn.close();}
	
	@Test
	@Order(2)
	public void text() {
		String text=driver.getTitle();
		System.out.println(text);
	}
	
	@Test
	@Order(3)
	public void login() throws InterruptedException {
		driver.findElement(By.id("user-name")).sendKeys("standard_user");	
		driver.findElement(By.id("password")).sendKeys("secret_sauce");	
		driver.findElement(By.id("login-button")).click();
		Thread.sleep(1000);
		//driver.navigate().to(actURL);

		}

	@Test
	@Order(4)
	public void addToCart() throws InterruptedException {
		driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id=\"react-burger-menu-btn\"]")).click();
		
		Thread.sleep(2000);
		driver.findElement(By.id("logout_sidebar_link")).click();
	}
}