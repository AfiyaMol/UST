package constructorstutorial;
// Implement a copy constructor to create a new object by copying another object's state
public class Person {
	
	    private String name;
	    private int age;

	    // Regular constructor
	    public Person(String name, int age) {
	        this.name = name;
	        this.age = age;
	    }

	    // Copy constructor
	    public Person(Person otherPerson) {
	        this.name = otherPerson.name;
	        this.age = otherPerson.age;
	    }

	    // Method to display person's details
	    public void display() {
	        System.out.println("Name: " + name + ", Age: " + age);
	    }

	    public static void main(String[] args) {
	        // Creating an object using the regular constructor
	        Person originalPerson = new Person("John Doe", 30);
	        originalPerson.display();

	        // Creating a new object by copying the state of the original object
	        Person copiedPerson = new Person(originalPerson);
	        copiedPerson.display();
	    }
	}


