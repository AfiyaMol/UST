package constructorstutorial;
//Write a program that uses the this keyword to call one constructor from another
public class ConstEg5 {	
	    int x;
	     int y;

	    // Constructor with no parameters
	    ConstEg5() {
	        this(0, 0); // Calls the constructor with two parameters
	    }

	    // Constructor with one parameter
	    ConstEg5(int x) {
	        this(x, 0); // Calls the constructor with two parameters
	    }

	    // Constructor with two parameters
	     ConstEg5(int x, int y) {
	        this.x = x;
	        this.y = y;
	    }

	    // Method to display values
	    public void display() {
	        System.out.println("x = " + x + ", y = " + y);
	    }

	    public static void main(String[] args) {
	    	ConstEg5 obj1 = new ConstEg5();
	    	ConstEg5 obj2 = new ConstEg5(5);
	    	ConstEg5 obj3 = new ConstEg5(5, 10);

	        obj1.display();
	        obj2.display();
	        obj3.display();
	    }
	}



