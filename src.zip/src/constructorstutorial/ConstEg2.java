package constructorstutorial;
//Create a program that shows constructor overloading in Java
public class ConstEg2 {

	
	int id;
	ConstEg2(int id){
		this.id=id;
		
		System.out.println("Constructor with one parameter");
	}
	int age;
	String name;
	
	ConstEg2(int age, String name){
		this.age=age;
		this.name=name;
		System.out.println("Constructor with two parameter");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ConstEg2 c=new  ConstEg2(1);
		 ConstEg2 c1=new  ConstEg2(24,"AAFI");
		 System.out.println("id is " +c.id);
		 System.out.println("age is " +c1.age  + " name is " +c1.name);
		 
	}

}
