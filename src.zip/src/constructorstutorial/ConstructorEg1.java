package constructorstutorial;
//Write a Java program to demonstrate a no-argument constructor
public class ConstructorEg1 {
	ConstructorEg1(){
		System.out.println("Constructor is created and called");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConstructorEg1 c= new ConstructorEg1();
	}

}
