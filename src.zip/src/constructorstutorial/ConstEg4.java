package constructorstutorial;
//Create a Java program to demonstrate constructor chaining
public class ConstEg4 {
	
	ConstEg4() {
	        this(5); // Calls the second constructor
	        System.out.println("The Default constructor");
	    }

	ConstEg4(int x) {
	        this(5, 15); // Calls the third constructor
	        System.out.println(x);
	    }

	ConstEg4(int x, int y) {
	        System.out.println(x * y);
	    }

	    public static void main(String args[]) {
	        new ConstEg4();
	    }
	}
