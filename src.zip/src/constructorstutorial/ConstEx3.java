package constructorstutorial;
// Implement a parameterized constructor to initialize an object
public class ConstEx3 {
	
	     String name;

	    // Parameterized constructor
	    public ConstEx3(String name) {
	        name = name;
	    }

	    // Getter method for name
	    public String getName() {
	        return name;
	    }

	    public static void main(String[] args) {
	        // Create an object using the parameterized constructor
	    	ConstEx3 obj = new ConstEx3("aafiya");

	        // Access the name using the getter method
	        System.out.println("Name: " + obj.getName());
	    }
	}
