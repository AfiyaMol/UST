package thread;

public class ThreadExample extends Thread
{

	

		public void run(){ System.out.println("thread is running..."); }
		  
		  public void start() { System.out.println("Thread is starting.."); }
		 

		public static void main(String[] args) throws InterruptedException 
		{

			ThreadExample t1 = new ThreadExample();
			t1.start();
			
			String name = t1.getName();
			System.out.println(name);
			State b1 = t1.getState();
			System.out.println(b1);
			
			 
			
			t1.run();
			t1.sleep(10000);
			long id = t1.getId();
			System.out.println(id);
			State b2 = t1.getState();
			System.out.println(b2);
			t1.run();
			boolean b = t1.isAlive();
			System.out.println(b);
			 
			

		}

	
	}

