package encapsulationpractice;

public class Rectangle {
	private int length;
	private int width;
	public int setRectangle(int l, int w) {
		if(l>w) System.out.println("Length is " +l);
		length=10;
		return length;
	}
	public int getRectangle() {
		width=5;
		return width;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Rectangle r= new Rectangle();
		 r.setRectangle(10, 5);
		 int w=r.getRectangle();
		 System.out.println( "width is " +w );
	}

}
