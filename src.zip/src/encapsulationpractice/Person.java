package encapsulationpractice;

public class Person {
 private String name;
 private int age;
 private String country;
 public void setPerson(String n, int a, String c) {
	 name="aafi";
//	 age=24;
	 country="india";
	 System.out.println("Name is " +name + "  and country is " +country);
	 
 }
 public int getPerson(){
	 return age=24;
	 
 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p= new Person();
		p.setPerson("aafi", 24, "india");
		int a=p.getPerson();
		System.out.println("age is " +a);

	}

}
