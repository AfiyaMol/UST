package encapsulationpractice;

public class BankAccount {
	private int balance;
	private long accountNo;
	public void setBankAccount() {
		balance=50000;
		accountNo=123412341 ;
		System.out.println("accountNo is " + accountNo);
		
	}
	public int getBankAccount() {
		
		return balance;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankAccount b= new BankAccount();
		b.setBankAccount();
		int balance=b.getBankAccount();
		System.out.println("balance is "+balance );
	}
	

}
