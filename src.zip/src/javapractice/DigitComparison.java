package javapractice;

import java.util.Scanner;

public class DigitComparison {
	
	    public static boolean compareLastDigit(int a, int b) {
	        // Get the last digit of each number
	        int a_last = a % 10;
	        int b_last = b % 10;
	        
	        // Compare the last digits
	        return a_last == b_last;
	    }
	

	
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	        // Accept two integers from the user
	        System.out.print("Enter the first integer: ");
	        int a = scanner.nextInt();
	        
	        System.out.print("Enter the second integer: ");
	        int b = scanner.nextInt();
	        
	        // Call the static method from UserMainCode
	        boolean result = DigitComparison.compareLastDigit(a, b);
	        
	        // Print the result
	        System.out.println("Same last digit: " + result);
	    }
	}

