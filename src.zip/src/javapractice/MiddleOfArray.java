package javapractice;

import java.util.Scanner;

public class MiddleOfArray {
	public static int getMiddleElement(int [] arr) {
		int mid=0;
		for(int i=0; i< arr.length; i++) {
		mid=(arr[0]+arr[arr.length-1])/2;
	}return mid;

}
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("array size ");
	        int size = scanner.nextInt();
	        int[] inputArray = new int[size];
	        System.out.println("array elements:");
	        for (int i = 0; i < size; ++i) inputArray[i] = scanner.nextInt();
	       int middle = MiddleOfArray.getMiddleElement(inputArray);
	       System.out.println("Middle element in the array: " + middle);
}
}