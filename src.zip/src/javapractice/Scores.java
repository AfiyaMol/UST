package javapractice;

import java.util.Scanner;

public class Scores {
	public static boolean checkScores(int [] n) {
	
		for(int i =0; i < n.length ; i++) {
			if(n[i] ==100 && n[i+1]== 100)
				return true;
		}
		return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scn = new Scanner(System.in);
System.out.println("enter array size");
int a= scn.nextInt();
int []n = new int[a];
for(int i =0; i< a; i++) {
	 n[i]=scn.nextInt();
	}
boolean res= Scores.checkScores(n);
System.out.println(res);
	}

}
