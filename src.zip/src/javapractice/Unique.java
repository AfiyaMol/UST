package javapractice;
import java.util.HashSet;
import java.util.Scanner;
public class Unique {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet<Integer> h=new HashSet<Integer>();
		Scanner scn= new Scanner(System.in);
		System.out.println("ENTER NUMBER");
		int n= scn.nextInt();
		//int n=22346;
		int count =0;
		for(int temp =n ; temp != 0;temp/=10) {
			int x= temp%10;
			h.add(x);
			count ++;
		}
		if(h.size()==count) {
			System.out.println(" unique");
		}
		else {
			System.out.println("not unique");
		}

	}

}
