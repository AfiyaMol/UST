package javapractice;

import java.util.Scanner;

public class Occurances {

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		int n=785765;
//		int count =0;
//		for(int i =0; i< n; i++) {
//			int d = n% 10;
//			if(d==7) {
//				count ++;}
//			n/=10;
//			
//			}
//		System.out.println(count);
//		}

	
	 public static int countSeven(int n) {
	        // Initialize count
	        int count = 0;

	        // Convert the integer to a string
	        String num = Integer.toString(n);

	        // Iterate through each digit in the string
	        for (char digits : num.toCharArray()) {
	            if (digits == '7') {
	                count++;
	            }
	        }

	        return count;
	    }
	

	
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        // Get input integer from user
	        System.out.print("Enter integers ");
	        int n = scanner.nextInt();

	        // Call the static method countSeven
	        int result = Occurances.countSeven(n);

	        // Print the result
	        System.out.println(result);
	    }
	}


