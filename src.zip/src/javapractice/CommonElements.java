package javapractice;

public class CommonElements {

    public static void main(String[] args) {
        int[] a = {1, 2, 3, 4, 5};
        int[] b = {13, 14, 15, 16};

        int sum = 0;

        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < b.length; j++) {
                if (a[i] == b[j]) {
                    sum += a[i];           
                }
            }
        }

        if (sum == 0) {
            System.out.println("No common elements");
        } else {
            System.out.println("Sum  " + sum);
        }
    }
}

