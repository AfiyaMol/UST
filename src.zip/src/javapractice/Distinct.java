package javapractice;

import java.util.HashSet;
import java.util.Scanner;

public class Distinct {
	    public static int calculateUnique(int a, int b, int c) {
	        // Create a set to store unique integers
	        HashSet<Integer> h = new HashSet<>();
	        h.add(a);
	        h.add(b);
	        h.add(c);
	        // Return the count of unique integers
	        return h.size();
	    }


	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Enter the three  integers ");
	        int a = scanner.nextInt();
	        int b = scanner.nextInt();  
	        int c = scanner.nextInt();
	        int result = Distinct.calculateUnique(a, b, c);
	        System.out.println(" unique integers: " + result);
	    }
	}


