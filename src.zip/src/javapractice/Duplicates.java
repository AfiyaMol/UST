package javapractice;

import java.util.Scanner;

public class Duplicates {

	public static int getDistinctSum(int a, int b ,int c) {
		 if (a == b) {
	            return c;
	        } else if (a == c) {
	            return b;
	        } else if (b == c) {
	            return a;
	        } else {
	            // If no two numbers are equal, return the sum of all three
	            return a + b + c;
	        }
	}
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter 3 values");
		int a=scn.nextInt();	
		int b=scn.nextInt();	
		int c=scn.nextInt();
		
		int res=Duplicates.getDistinctSum(a,b,c);
		System.out.println(res);// TODO Auto-generated method stub

	}

}
