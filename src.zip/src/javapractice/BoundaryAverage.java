package javapractice;

import java.util.Scanner;

public class BoundaryAverage {
	public static float getBoundaryAverage(int [] a) {
		int min =0;
		int max=0;
		float avg=0;
		for(int i =0; i< a.length; i++) {
			if(a[i]< min) {
				min = a[i];
				
			}
			if(a[i] > max) {
				max= a[i];
				
			}
			
			avg= (min + max)/2.0f;
		} return avg;
		
	}
	public static void main(String [] args) {
		Scanner scanner = new Scanner(System.in);

        // Get input array from user
       System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        int[] arr = new int[n];
        System.out.print("Enter the elements of the array separated by space: ");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        // Call the static method getBoundaryAverage
        float result = BoundaryAverage.getBoundaryAverage(arr);

        // Print the result
        System.out.printf("The average of the maximum and minimum elements in the array is: %.2f%n", result);
    }
}
	


