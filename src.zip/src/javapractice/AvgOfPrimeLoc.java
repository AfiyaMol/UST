package javapractice;

import java.util.Scanner;

public class AvgOfPrimeLoc {
	
	 private static boolean isPrime(int n) {
	        if (n < 2) return false;
	        for (int i = 2; i  <= n/2; ++i)
	            if (n % i == 0) return false;
	        return true;
	    }

	    public static double average(int[] arr) {
	        double sum = 0;
	        int count = 0;
	        for (int i = 0; i < arr.length; ++i)
	            if (isPrime(i)) {
	                sum += arr[i];
	                count++;
	            }
	      //  if (count > 0) {
	            double avg = sum / count;
	            return avg;
	      //  } else {
	           // return 0.0;
	       // }
	    }
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("array size ");
	        int size = scanner.nextInt();
	        int[] inputArray = new int[size];
	        System.out.println("array elements:");
	        for (int i = 0; i < size; ++i) inputArray[i] = scanner.nextInt();
	        double average = AvgOfPrimeLoc.average(inputArray);
	        System.out.println("Average of elements at prime indexes: " + average);
	    }
}