package wecp;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InputPassword {
	public static void main(String[] args) {
		System.out.println("enter a password");
		Scanner scn = new Scanner(System.in);
		String pswd=scn.next();
		
		// TODO Auto-generated method stub
		Pattern p= Pattern.compile("(?=.*[!@#$%])(?=.*[0-9])(?=.*[A-Z]).{5,10}");
		Matcher m=p.matcher(pswd);
		
		System.out.println(m.matches());
		
				
		}

}
