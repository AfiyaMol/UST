package wecp;

import java.util.Scanner;
import java.util.StringTokenizer;

public class StringConcatWithTokenizer {
    public static String concat(String s1, String s2) {
        // Create a StringBuilder to store the concatenated result
        StringBuilder result = new StringBuilder();

        // Initialize a string tokenizer for s1 using space as the delimiter
        StringTokenizer tokenizer1 = new StringTokenizer(s1, " ");

        // Append tokens from s1 to the result
        while (tokenizer1.hasMoreTokens()) {
            result.append(tokenizer1.nextToken());
        }

        // Initialize a string tokenizer for s2 using space as the delimiter
        StringTokenizer tokenizer2 = new StringTokenizer(s2, " ");

        // Append tokens from s2 to the result
        while (tokenizer2.hasMoreTokens()) {
            result.append(tokenizer2.nextToken());
        }

        return result.toString();
    }

    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Enter two strings:");
        String s1 = scn.nextLine();
        String s2 = scn.nextLine();

        System.out.println("Concatenated result using string tokenizer: " + StringConcatWithTokenizer.concat(s1, s2));
    }
}
