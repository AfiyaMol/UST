package wecp;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IDvalidation {
	public static String validate(String id, String loc) {
		Pattern pattern =Pattern.compile("[A-Z]{3}-[a-z]{3}-[0-9]{3}");
		Matcher matcher=pattern.matcher(id);
		if(matcher.matches()) 
			return "valid";

		else
		return "invalid";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		System.out.println("enter id  and location");
		String id=scn.nextLine();
		String loc=scn.nextLine();
		
		System.out.println(IDvalidation.validate(id, loc));

	}

}
