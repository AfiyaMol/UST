package wecp;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PyramidSum {


	private static int pSum(int array_length, List<Integer> arr) {
		while(arr.size() > 1) {
			List<Integer> newArr = new ArrayList<>(array_length);
			for(int i =0; i< array_length -1; i++) {
				newArr.add(arr.get(i) + arr.get(i+1));
				
			}
			arr = newArr;
		}
		return arr.get(0);
	}
	
	public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
    
        int array_length = Integer.parseInt(scan.nextLine().trim());
        
        List<Integer> arr = new ArrayList<>(array_length);
        for(int j=0; j<array_length; j++) {
            arr.add(Integer.parseInt(scan.nextLine().trim()));
        }
    
        int result = pSum(array_length, arr);
    
        System.out.println(result);
    }

}
