package wecp;

import java.util.Scanner;

public class FirstandLastElement {
	
	public static int checkCharacters(String S) {
		int i =0;
		int j=S.length()-1;
		while(i < j) {
			if(S.charAt(i) == S.charAt(j)) return 1;
				//System.out.println("valid");
			//else System.out.println("invalid");
		}
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		System.out.println("enter a string");
		String s= scn.nextLine();
		int res=checkCharacters(s);
		System.out.println(res);
	}

}
