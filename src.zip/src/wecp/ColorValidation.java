package wecp;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ColorValidation {
	public static String validate(String s) {
		Pattern pattern=Pattern.compile("#{1}[A-F0-9]{6}");
		Matcher matcher=pattern.matcher(s);
		if(matcher.matches()) return "valid";
		else 
		return "invalid";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		System.out.println("enter the color code");
		String s= scn.nextLine();
		
		System.out.println(ColorValidation.validate(s));
		

	}

}
