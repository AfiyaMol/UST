package wecp;

import java.util.Scanner;

public class InitialFormat {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 
		System.out.println("enter name");
	    String str = sc.nextLine(); 
	   // System.out.println();
	    String [] name = str.split(" "); 
	    
	    String firstName = name[0];
        String lastName = name[1];

        // Get the initial of the first name
        char Formatter = firstName.charAt(0);

        // Format the name as "LastName, InitialOfFirstName"
        String InitialFormat = lastName + ", " + Formatter ;
        System.out.println(InitialFormat);

        
    }


}
