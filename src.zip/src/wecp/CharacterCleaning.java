package wecp;

import java.util.Scanner;

public class CharacterCleaning{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		System.out.println("enter string");
		String str = scn.nextLine();
		System.out.println("enter character");
		String c=scn.next();
		
		String result = str.replace(String.valueOf(c), "");
		System.out.println(result);

	}

}
