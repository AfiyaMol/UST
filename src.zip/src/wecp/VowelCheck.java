//package wecp;
//
//import java.util.Scanner;
//
//public class VowelCheck {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//Scanner scn = new Scanner(System.in);
//String s= scn.nextLine();
//for(int i =0 ; i< s.length(); i++) {
//char ch[]= new char(s.length());
//if(ch(i)=='a' && s(i)=='e' && s(i)=='i' && s(i)=='o' && s(i)=='u' ) {
//	}
//
//}
