package wecp;

import java.util.Scanner;

public class SumOfDigits {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("enter string");
		String s=scn.nextLine();
		int sum=0;
		char ch[]= s.toCharArray();
		for(int i =0;i< ch.length;i++) {
			char ch1= ch[i];
			if(ch1>='0' && ch1<='9') {
				sum  += (ch1-'0');
			}
		}
		// TODO Auto-generated method stub
System.out.println(sum);
	}

}
