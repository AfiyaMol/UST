package wecp;

import java.util.Scanner;

public class MiddleElements {
	public static String middleTwoValues(String S) {
	
		for(int i=0; i<S.length(); i++) {
			if(S.length() %2 !=0)     return "NOT EVEN LENGTH";
		}
		
		int middleIndex1 = S.length() / 2 - 1;
        int middleIndex2 = middleIndex1 + 1;

   return S.substring(middleIndex1, middleIndex2 + 1);
	}
	
	public static void main(String[] args) {
		Scanner scn =new Scanner(System.in);
		
		System.out.println("enter a string");
		String string=scn.nextLine();
		System.out.println(middleTwoValues(string));
	}
}



 