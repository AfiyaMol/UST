package wecp;

import java.util.Scanner;

public class RemoveVowels {

		    public static String removeEvenVowels(String input) {
	        StringBuilder sb = new StringBuilder();
	        for (int i = 0; i < input.length(); i++) {
	            char ch = input.charAt(i);
	            if (!isVowel(ch) && (i + 1) % 2 == 0) {
	                sb.append(ch);
	            }
	        }
	        return sb.toString();
	    }

	    private static boolean isVowel(char c) {
	        c = Character.toLowerCase(c);
	        return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u';
	    }
	
	    public static void main(String[] args) {
	    	Scanner scn = new Scanner(System.in);
	    	System.out.println("enter string");
	        String s = scn.nextLine();
	        String result = RemoveVowels.removeEvenVowels(s);
	        System.out.println("Modified string: " + result);
	    }
	}
