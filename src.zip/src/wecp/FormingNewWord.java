package wecp;

import java.util.Scanner;

public class FormingNewWord {
	public static String newWord(String s, int n) {
		String word= new String();
		if(s.length() < n*2) return "Invalid";
		
		       word=s.substring(0, n) + s.substring(s.length()-n, s.length());
						return word;

		    
	}
		    public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);
		        System.out.print("Enter a string: ");
		        String s = scanner.nextLine();

		        System.out.print("Enter a integer: ");
		        int n = scanner.nextInt();

		       
		        String result = FormingNewWord.newWord(s, n);
		        System.out.println("New word: " + result);
		    }
		}

	