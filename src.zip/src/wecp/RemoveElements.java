package wecp;
import java.util.Arrays;
import java.util.Scanner;
public class RemoveElements {
	    public static int elements(String[] a, int n, int r) {
	        int size = 0;
	        for (int i = 0; i < n; i++) {
	            if (a[i].length() != r) {
	                a[size] = a[i];
	                size++;
	            }
	        }
	        return size;
	    }
	    public static void main(String[] args) {
	        Scanner scn = new Scanner(System.in);
	        System.out.println("enter string size");
	        int n =scn.nextInt();
	        String[] a = new String[n];
	        System.out.println("Enter the string elements ");
	        for (int i = 0; i <= n; i++) {
	            a[i] = scn.nextLine();
	        }
	        System.out.println("remove string of size");
	        int r =scn.nextInt();
	       // int size = RemoveElements.elements(a, n, r);

	        //System.out.println("Original Array: " + Arrays.toString(a));
	       System.out.println(RemoveElements.elements(a, n, r));
	    }
	}



