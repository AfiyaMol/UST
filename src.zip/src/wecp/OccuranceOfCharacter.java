package wecp;
import java.util.Scanner;

public class OccuranceOfCharacter {

	
	
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in); // Create a Scanner object

	        System.out.print("Enter a string: ");
	        String s = scanner.nextLine(); // Read the user input

	        System.out.print("Enter the character to count: ");
	        char ch = scanner.next().charAt(0); // Read the target character

	    

	        int count = 0;
	        for (int i = 0; i < s.length(); i++) {
	            if (s.charAt(i) == ch) {
	                count++;
	            }
	        }

	        System.out.println("Occurrences of " + ch +" = " + count);
	    }
	}


