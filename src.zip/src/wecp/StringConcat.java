package wecp;

import java.util.Scanner;
public class StringConcat {
	public static String concat(String s1, String s2) {
		String str="";
		if(s1.length()==s2.length()) {
			str += s1+ s2;
		}else{
			int minLength = (s1.length() < s2.length()) ? s1.length() : s2.length();
        String newS1 = s1.substring(s1.length() - minLength);
        String newS2 = s2.substring(s2.length() - minLength);
        return  newS1 + newS2;
		}
		return str;
	}
	public static void main(String[] args) {
		Scanner scn =new Scanner(System.in);
		System.out.println("enter two strings");
		String s1=scn.nextLine();
		String s2=scn.nextLine();
		
		System.out.println(StringConcat.concat(s1, s2));
		
	}

}
