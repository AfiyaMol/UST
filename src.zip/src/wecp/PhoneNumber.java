package wecp;
import java.util.Scanner;
import java.util.regex.*;
public class PhoneNumber {
	    public static int validateNumber(String phoneNumber) {
	        Pattern pattern = Pattern.compile("\\d{10}|[1-9]{3}-[1-9]{3}-[0-9]{4}");
	        Matcher matcher = pattern.matcher(phoneNumber);
	        
	        if (matcher.matches()) {
	            return 1; // Valid format
	        } else {
	            return -1; // Invalid format
	        }
	    }
	    public static void main(String[] args) {
	        Scanner scn = new Scanner(System.in);
	        System.out.println("Enter a phone number (10 digits or XXX-XXX-XXXX):");
	        String phoneNumber = scn.nextLine();

	        int result = validateNumber(phoneNumber);
	        if (result == 1) {
	            System.out.println("Valid Number");
	        } else {
	            System.out.println("Invalid Number");
	        }
	    }
	}
