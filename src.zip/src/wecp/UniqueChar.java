package wecp;

import java.util.HashSet;
import java.util.Scanner;

public class UniqueChar {
 

	    public static void main(String[] args) {
	    	Scanner scn =new Scanner(System.in);
	    	System.out.println("enter word1");
	        String s1 = scn.nextLine();
	        System.out.println("enter word2");
	        String s2 = scn.nextLine();
	        // Find common letters
	        HashSet<Character> commonLetters = new HashSet<>();
	        for (char ch : s1.toCharArray()) {
	            if (s2.indexOf(ch) != -1) {
	                commonLetters.add(ch);
	            }
	        }
	        System.out.println("Common letters: " + commonLetters);

	        // Find unique letters
	        HashSet<Character> uniqueSet = new HashSet<>();
	        for (char ch : s1.toCharArray()) {
	            uniqueSet.add(ch);
	        }
	        for (char ch : s2.toCharArray()) {
	            uniqueSet.add(ch);
	        }
	        System.out.println("Unique letters count: " + uniqueSet.size());
	    }
	}
