package wecp;

import java.util.Scanner;

	public class FileExtension {
		public static String file(String str) {
			int index=str.indexOf('.');
			if (index > 0) 
	            return str.substring(index + 1);
	         else 
	            return "No extension found";
	      	
		}
	
		public static void main(String[] args) {
			// TODO Auto-generated method stub
	Scanner scn = new Scanner(System.in);
	System.out.println("enter file name");
	String s= scn.nextLine();
	
	System.out.println(FileExtension.file(s));
	 


	}

}
