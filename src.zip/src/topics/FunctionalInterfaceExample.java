package topics;

interface sayable {

    void say(String msg);  
     
    default void doIt(){  
        System.out.println("Do it now");  
    }  

}
public class FunctionalInterfaceExample implements sayable
{  
    
    public static void main(String[] args) {  
       // FunctionalInterfaceExample fie = new FunctionalInterfaceExample(); 
        
    	FunctionalInterfaceExample obj =   new FunctionalInterfaceExample();
        obj.say("Hello there");  
        
        obj.doIt();
    }

	@Override
	public void say(String msg) {
		System.out.println(msg);	
	}
}  
