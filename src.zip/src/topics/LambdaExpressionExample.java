package topics;

interface Drawable {
public void draw();  
    
    default void run()
    {
    	System.out.println("Hello");
    }
     
}  

public class LambdaExpressionExample   

{  
    public static void main(String[] args) 
    {  
        int width=10; 
        
        Drawable obj = ()-> {
        	
        	System.out.println("Drawing "+width);   
        	
        	
        };
        obj.run();
        obj.draw();   
    }

	private void draw() {
		// TODO Auto-generated method stub
		 System.out.println("Drawing something");
		
	}

	private void run() {
		// TODO Auto-generated method stub
		 System.out.println("Running something");
	}
}
