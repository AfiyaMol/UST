package javahomework;

public class Strings {
	
	    public static void main(String[] args) {
	        String emptyString = "";

	        //write your code here
	        System.out.println(emptyString.length());
	        System.out.println("Gomu Gomu no Bazooka!".length());
	        System.out.println((emptyString + 2 + 2 + "22".length()));
	        System.out.println("of Edo's rain".length());
	        System.out.println("how many mouthfuls did you drink,".length());
	        System.out.println("cuckoo?".length());
	    }
	}

