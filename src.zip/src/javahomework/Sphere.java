package javahomework;

public class Sphere {
	public int x;
    public int y;
    public int z;
    public double r;
    
    public Sphere(int x, int y, int z, double r){
    this.x=x;
    this.y= y;
    this.z= z;
    this.r= r;
    	
    }

    //write your code here
    public static void main(String[] args) {
    	Sphere s=new Sphere(2,4,6, 3.04);
    	
    	System.out.println(s.x);
    	System.out.println(s.y);
    	System.out.println(s.z);
    	System.out.println(s.r);

    }
}

