package javahomework;

public class SquareAndCube {
	public static void main(String[] args) {
        int number = 3;
        System.out.printf("%d - %d - %d", number, sqr(number), cube(number));
    }

	public static int cube(int number) {
		// TODO Auto-generated method stub
		return number*number*number;
	
	}

	public static int sqr(int number) {
		
		return number * number;
	}

}
