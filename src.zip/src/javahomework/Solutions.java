package javahomework;

public class Solutions {
	
	    public static void main(String[] args) {
	        String name = "Amigo";
	        int age = 10;
	        greeting(name, age);
	        System.out.print("Hello. My name is " +name);
	        System.out.print( ".I am " +age);
	    }
	    //write your code here

		public static void greeting(String name, int age) {
			// TODO Auto-generated method stub
			
		}
	}



