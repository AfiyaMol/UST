package javahomework;

import java.util.Scanner;

public class ReadFromKeyboard {


    public static char[] vowels = "aeiou".toCharArray();
    public static char[] consonants = "bcdfghjklmnpqrstvwxyz".toCharArray();

    public static void main(String[] args) throws Exception {
        //write your code here
    	Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();
        scanner.close();

        // Process the input string
        String[] lines = processInput(input);

        // Display the results
        for (String line : lines) {
            System.out.println(line);
        }

    } public static String[] processInput(String input) {
        StringBuilder vowelsLine = new StringBuilder();
        StringBuilder consonantsLine = new StringBuilder();
        StringBuilder punctuationLine = new StringBuilder();

        for (char character : input.toCharArray()) {
            if (Character.isLetter(character)) {
                if (isVowel(character)) {
                    vowelsLine.append(character).append(" ");
                } else {
                    consonantsLine.append(character).append(" ");
                }
            } else if (Character.isWhitespace(character)) {
                // Ignore whitespace
            } else {
                punctuationLine.append(character).append(" ");
            }
        }

        return new String[]{
                vowelsLine.toString().trim(),
                consonantsLine.toString().trim(),
                punctuationLine.toString().trim()
        };
    }

    // The method checks whether a letter is a vowel
    public static boolean isVowel(char character) {
        character = Character.toLowerCase(character);  // Convert to lowercase
        for (char vowel : vowels) {  // Look for vowels in the array
            if (character == vowel) {
                return true;
            }
        }
        return false;
    }

    // The method checks whether a letter is a consonant
    public static boolean isConsonant(char character) {
        character = Character.toLowerCase(character);  // Convert to lowercase
        for (char vowel : consonants) {  // Look for consonants in the array
            if (character == vowel) {
                return true;
            }
        }
        return false;
    }
}

