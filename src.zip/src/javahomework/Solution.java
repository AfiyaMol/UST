package javahomework;

public class Solution {
    public static void main(String[] args) {
        Rabbit r1 = new Rabbit();
        Rabbit r2 = new Rabbit();
        System.out.println(r1);
        System.out.println(r2);

        Horse h1 = new Horse("JOHNBOY");
        Horse h2 = new Horse("ARTHUR");
        System.out.println(h1);
        System.out.println(h2);

        Hamster hamster1 = new Hamster("HAM");
        Hamster hamster2 = new Hamster("STER");
        System.out.println(hamster1);
        System.out.println(hamster2);
    }

    public static class Rabbit {
        public String toString() {
            return "Rabbit";
        }
    }

    public static class Horse {
        String name;

        public Horse(String name) {
            this.name = name;
        }

        public String toString() {
            return "Horse: " + name;
        }
    }

    public static class Hamster {
        String name;

        public Hamster(String name) {
            this.name = name;
        }

        public String toString() {
            return "Hamster: " + name;
        }
    }
}

