package javahomework;

public class Calculator {

    public static void main(String[] args) {
        System.out.println(calc(1, '+', 2));
        System.out.println(calc(5, '-', 3));
        System.out.println(calc(2, '*', 3));
        System.out.println(calc(20, '/', 5));
    }
    //write your code here

	public static int calc(int i, char c, int j) {
		// TODO Auto-generated method stub
		int result=0;
		switch (c) {
        case '+':
            return i + j;
        case '-':
            return i - j;
        case '*':
            return i * j;
        case '/':
            if (j != 0) {
                return i / j;
            } else {
                System.out.println("Error: Division by zero.");
                return 0;
            }
        default:
            System.out.println("Error: Invalid operator.");
    
	}
		return 0;

	}
}
