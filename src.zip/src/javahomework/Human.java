package javahomework;

public class Human {
	
	    String name;
	    char sex;
	    int money;
	    int weight;
	    double size;

	   
	  
	    public void initialize(String name, int money, char sex, int weight, double size) {
	        this.name = name;
	        this.money = money;
	        this.sex = sex;
	        this.weight= weight;
	        this.size= size;
	    }

	    public static void main(String[] args) {
	    	Human h= new Human();
	    	h.initialize("aafi", 250000, 'F', 47, 32.0);
	    	System.out.println(h.name);
	    	System.out.println(h.money);
	    	System.out.println(h.sex);
	    	System.out.println(h.weight);
	   		System.out.println(h.size);
	    }
}
