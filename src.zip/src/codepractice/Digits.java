package codepractice;

import java.util.Scanner;

public class Digits {
	
	public static int prodOf(int a) {
		int prod=1;
		while(a>0) {
			int n=a%10;
			prod=prod*n;
			a=a/10;
		}
		return prod;
	}
	
	public static int sumOf(int a) {
		int sum=0;
		while(a>0) {
			int m=a%10;
			sum=sum + m;
			a=a/10;
		}
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scn=new Scanner(System.in);
		
		System.out.println("enter a digit");
		int a=scn.nextInt();
		
		if(a>=100 && a<1000 ) 
			System.out.println("three digit number is " +sumOf(a));
		
		else if (a>=10 && a<100) 
			System.out.println("two digit number is " +prodOf(a));
		
		else 
			System.out.println("one digit number is " +a);

	}

}
