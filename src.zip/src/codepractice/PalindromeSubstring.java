package codepractice;
import java.util.ArrayList;
import java.util.List;

public class PalindromeSubstring {
	
	    public static void main(String[] args) {
	        String input = "bob has a radar plane";
	        String result = replacePalindromicSubStrings(input);
	        System.out.println("Modified string: " + result);
	    }

	    public static String replacePalindromicSubStrings(String input) {
	        List<String> palindromicSubstrings = new ArrayList<>();
	        for (int i = 0; i < input.length(); i++) {
	            for (int j = i + 2; j <= input.length(); j++) {
	                String subString = input.substring(i, j);
	                if (isPalindrome(subString)) {
	                    palindromicSubstrings.add(subString);
	                }
	            }
	        }

	        for (String palindrome : palindromicSubstrings) {
	            input = input.replace(palindrome, "*".repeat(palindrome.length()));
	        }

	        return input;
	    }

	    public static boolean isPalindrome(String str) {
			int i =0;
			int j = str.length()-1 ;
		while(i <= j) {
			if(str.charAt(i)!=  str.charAt(j))
				return false;
					i++;
					j--;
				}
				return true;
		}
	}
	




