package codepractice;

import java.util.Scanner;

public class Palindrome {
	
	public static boolean isPalindrome(String str) {
		int i =0;

		int j = str.length()-1 ;
	
	while(i <= j) {
		if(str.charAt(i)!=  str.charAt(j))
			return false;
				i++;
				j--;
			}
			return true;
	}
	public static void main(String [] args) {
		Scanner sc = new Scanner(System.in); // Create a Scanner object
        System.out.print("Enter a string: ");
        String str = sc.nextLine(); // Read the entire line of input
        System.out.println(isPalindrome(str));
		
	}
	}

//for(int i=word.length() -1; i>=0; i--) {
//
//reverse += word.charAt(i);
//		
//}
//
//if(word.equals(reverse)) {
//
//System.out.println("it is palindrome");
//}
//else {
//System.out.println("Not palindrome");
//}
