package codepractice;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Query {
	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter the string:"); 
	String input = scanner.nextLine();
	column(input);
}	
	public static void column(String input)
	{
		//Extracting columns part
		String columnsPart= " ";
        if (input.contains("select")) {
            int start = input.indexOf("select") + "select".length();
            int end = input.indexOf("from");
            columnsPart = input.substring(start, end).trim();
        }
        System.out.println("The coloumns are: "+columnsPart);
        
        //Extracting the conditions
        List<String> list = new ArrayList<>();
        if (input.contains("where"))
        {
            int start = input.indexOf("where") + "where".length();
            String conditions = input.substring(start).trim();
            String[] arr = conditions.split("(and|or)");
            for (String condition : arr)
            {
                list.add(condition.trim());
            }
        }
        String result=list.toString();
        System.out.println("The conditions are: "+result);
        //Extracting the conditions seperately
        //Extracting logical operators part
        List<String> opList= new ArrayList<>();
        String[] logical={"and","or"};
        for(String op: logical)
        {
        	if(input.contains(op))
        		opList.add(op);
        }
        System.out.println("The operators are: "+opList.toString());	
	}
}
	
//Input String
//select * from employee
//select col1,col2 from employee
//select * from employee where empid=101
//select * from employee where empid=101 and emploc=trivandrum or role=permanent
//Extract
//columns part - col1,col2 ( for input 2)
//Basic query part ( select * from employee)
//conditions - (empid=101,emploc=trivandrum,role=permanent)
//logical operators (and,or)
//conditions part ( [empid,=,101],[emploc,=,trivandrum],[role,=,permanent]
	