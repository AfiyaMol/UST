package codepractice;

import java.util.Scanner;

public class FloatNumProd {

	public static float prod(float a, float b) {
		float c=a*b;
		return c;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn=new Scanner(System.in);
		System.out.println("enter a digit");
		float a=scn.nextFloat();
		
		System.out.println("enter new digit");
		float b=scn.nextFloat();
		
		System.out.println(prod(a,b));
	//	System.out.println(c);
		
	}

}
