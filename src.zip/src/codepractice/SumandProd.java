package codepractice;
import java.util.Scanner;
public class SumandProd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner scn=new Scanner(System.in);
	System.out.println("enter a digit");
	int a=scn.nextInt();
	
	System.out.println("enter new digit");
	int b=scn.nextInt();

	if((a>0&&b>0)|| (a<0&&b<0)) {
	int c= a*b;
	System.out.println(c);
	}
	
	else {
		int d=a+b;
		System.out.println(d);
		}
	}

}
