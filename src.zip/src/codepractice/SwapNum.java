package codepractice;
import java.util.Scanner;

public class SwapNum {

	public static void swapNum(int a, int b) {
		int temp=a;
		 a=b;
		 b= temp;
		System.out.println("After swap a=" +a  +"and b=" +b );
	}
	public static void main(String[] args) {
		Scanner scn=new Scanner(System.in);
	
		System.out.println("enter a digit");
		int a=scn.nextInt();
		
		System.out.println("enter new digit");
		int b=scn.nextInt();
		
		System.out.println("before swap  a=" +a + "and b=" +b);
		swapNum(a,b);

	}

}
