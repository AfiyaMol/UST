package codepractice;
import java.util.Scanner;

public class LargestNum {

	public static int largenum(int n, int m) {
		int c = 0;
		if (n > m) {
			c = n - m; //if n is greater than m, sub m from n
		}
		return c;
	}
 
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter first no");
		int n = sc.nextInt();
 
		System.out.println("enter second no");
		int m = sc.nextInt();
		
		System.out.println(largenum(n,m));
	}
 
}