package codepractice;

public class SortFriendsName {

	public static void main(String[] args) {
		String [] s= {"vishnu" ,"mohan", "vishnu k", "amritha", "aromal", "aswathy"};
		
		for(int i =0; i < s.length; i++) {
			for(int j=i+1; j < s.length; j++) {
				if(s[i].compareTo(s[j])>1) {
					String temp= s[i];
					 s[i]=s[j];
					 s[j]= temp;
					
				}
			}
			
		}
		// TODO Auto-generated method stub
		for (String name : s) {
            System.out.println(name);
	}
	}
}
