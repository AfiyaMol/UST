package codepractice;

import java.util.Scanner;

public class AbbrevationsOfName {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 
		System.out.println("enter name");
	    String str = sc.nextLine(); 
	   // System.out.println();
	    String [] name = str.split(" "); 
	   
	    for(int i=0; i <name.length ; i++) {
	    	if(i != name.length -1) {
	    	System.out.print(name[i].charAt(0));
	    	System.out.print(".");	
	    	}else {
	    		System.out.print(name[i]);
	    	}
	    }
	}
}


//public static String generateAbbreviations(String str) {
//	String[] str1 = str.split(" ");
//	String abbreviation = "";
//	for(int i=0;i<str1.length;i++) {
//		if(i!=str1.length - 1)
//		{
//			abbreviation += str1[i].charAt(0) + ".";
//		}
//		else {
//			abbreviation += str1[i];
//		}
//		
//	}
//	return abbreviation;
//	
//}


