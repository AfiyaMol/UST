package javacoding;

import java.util.Scanner;

public class Ncr {

	static int fact(int n) {
		int prod=1;
		for(int i =0;i <= n;i++) {
			prod=prod*i;
		}
		return prod;
	}
	static int ncr(int n, int r) {

		int nCr=(fact(n)/(fact(r)*fact(n-r)));
		return nCr;
	}
	
	
	public static void main(String[] args) {
		Scanner scn=new Scanner(System.in);
		System.out.println("enter values");
		int n=scn.nextInt(); //n>r
		int r=scn.nextInt();
		int res=ncr(n,r);
		System.out.println(res);
	}

}
