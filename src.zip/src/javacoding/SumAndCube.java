package javacoding;

public class SumAndCube {
	
	static int sumOfSqAndCube(int [] a) {
		int sum=0;
		for(int i=0;i<a.length;i++) {
			if(a[i] %2 !=0) {
				sum+= a[i]* a[i]* a[i];
							}
			else {
				sum+=a[i]*a[i];
			}
		}
		return sum;	
	}
	public static void main(String[] args) {
		int []a= {2,6,3,4,5};
		System.out.println(sumOfSqAndCube(a));
	}

}
