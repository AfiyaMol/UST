package javacoding;

import java.util.Scanner;
public class SumOfPowers {
    public static int PowerSum(int[] arr) {
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            int power = 1;
            for (int j = 0; j < i; j++) {
                power *= arr[i];
            }
            sum += power;
        }
        return sum;
    }  
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of elements: ");
        int n = scanner.nextInt();
        int[] arr = new int[n];
        System.out.println("Enter " + n + " elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }
        int totalSum = PowerSum(arr);
        System.out.println("The sum of powers of elements in the array is: " + totalSum);
    }
}

