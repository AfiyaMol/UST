package javacoding;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortandMerge {
	
	static ArrayList sort(ArrayList<Integer>arr1) {
		Collections.sort(arr1);
		
		 ArrayList<Integer> arr= new ArrayList<Integer>();
		 arr.add(arr1.get(2));
		 arr.add(arr1.get(6));
		 arr.add(arr1.get(8));
		 
		 return arr;
	}

    public static void main(String[] args) {
        // Create two ArrayLists
    	int n=5;
        ArrayList<Integer> arr1 = new ArrayList<Integer>(n);
        ArrayList<Integer> arr2 = new ArrayList<Integer>(n);

        // Add elements to list1 and list2 
        arr1.add(3);
        arr1.add(1);
        arr1.add(17);
        arr1.add(11);
        arr1.add(19);

        arr2.add(5);
        arr2.add(2);
        arr2.add(7);
        arr2.add(6);
        arr2.add(20);
        
        arr1.addAll(arr2);

      ArrayList<Integer> res =sort(arr1);
      System.out.println(res);
    }
}
