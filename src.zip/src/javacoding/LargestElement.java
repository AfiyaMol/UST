package javacoding;

public class LargestElement {

	static int checkLargest(int [] a ) {
		int mid=a[(a.length-1)/2];
		int start=a[0];
		int end=a[a.length-1];
	
	int largest = start > mid ? (start > end ? start : end) : (mid > end ? mid : end);
        return largest;		 
	}
	/* if(start>mid)
	{
		if(start>end)
		{
			start=start;
		}
	}
	else
	{
		if(mid>end)
		{
			start=mid;
		}
		else
		{
			start=end;
		}
		
	}
	return start;
}
	
	*/

	public static void main(String[] args) {
		int [] a= {59, 3, 8, 4,35};
System.out.println(checkLargest(a));
	}

}
