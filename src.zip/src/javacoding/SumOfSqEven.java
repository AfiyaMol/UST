package javacoding;

public class SumOfSqEven {
	static int sumOfSquaresOfEvenDigits(int n) {
		int sum=0;
		while(n>0) {
			int k=n%10;
			if(k%2==0) {
				sum += k*k;
			}
			n=n/10;
			
		}
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//int a=56895;
		int a=84228;
	       
		System.out.println(sumOfSquaresOfEvenDigits(a));
	}

}
