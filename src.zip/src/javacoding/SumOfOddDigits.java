package javacoding;

public class SumOfOddDigits {
	 static int checkSum(int n){
	        int sum=0;
	        while(n>0){
	            int k=n%10;
	            if(k%2!=0){
	            sum = sum+k;
	            }
	            n=n/10;
	        		}
	            if (sum % 2 != 0) {
	               return 1;
	            }
	            else{ 
	            return -1;
	            }
	    }
	    public static void main(String[] args) {
	        //int a=84228;
	        int a=56895;
	    	System.out.println(checkSum(a));
	    }

}
