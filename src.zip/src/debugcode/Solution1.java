package debugcode;

public class Solution1 {

	 private static int numberOfMonth = 3; // January - 1, February - 2, ..., December - 12

	    public static void main(String[] args) {
	        int condition1 =12;
	        int condition2 =3;
	        int condition3 =2;
	    
	        boolean isWinter = numberOfMonth== condition1 || numberOfMonth== condition2 ||numberOfMonth== condition3;
	        System.out.println(isWinter);
	    }
	}