package debugcode;

public class Solution {

	private static int numberDayOfWeek = 2; // Sunday - 0, Monday - 1, ..., Saturday - 6.
     
    public static void main(String[] args) {
    	
        boolean isWeekEnd = numberDayOfWeek ==0 || numberDayOfWeek == 6;  //checking whether no day of week == 0 or 6
 
        System.out.println(isWeekEnd);  // true for sat & sun
    }
}