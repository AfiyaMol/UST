package com.ust.Assignment;
import org.openqa.selenium.WebDriver;
import com.ust.Assignment.BrowserImplementation.Browser;
import verifiication.LandingPage;
public class Test {
	public static void main(String[] args) {
		WebDriver driver;
		Browser obj;
		obj = new Browser();
		// driver = obj.launch_Chrome();
		driver = obj.launch_Edge();
		driver.get("https://petstore.octoperf.com/");
		LandingPage lp = new LandingPage(driver);
		lp.verify_Title();
		lp.verify_Url();
		lp.verify_Text();
		driver.quit();
	}
}


