package verifiication;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LandingPage {
	WebDriver driver;
	public LandingPage(WebDriver driver)
	{
		this.driver = driver;
	}
	public void verify_Title() {
		System.out.println(driver.getTitle());
		
	}
	public void verify_Url() {
		System.out.println(	driver.getCurrentUrl());
		
	}
	public void verify_Text() {
		String text = driver.findElement(By.linkText("Enter the Store")).getText();
		System.out.println(text);
	}
}


