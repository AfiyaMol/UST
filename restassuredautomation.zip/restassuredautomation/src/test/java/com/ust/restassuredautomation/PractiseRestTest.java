package com.ust.restassuredautomation;
import static org.hamcrest.Matchers.lessThan;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
public class PractiseRestTest {
	
	@Test
	public void getTest() {
	RestAssured.useRelaxedHTTPSValidation();
	Response res = RestAssured.get("https://reqres.in/api/users/2");
	System.out.println(res.getStatusCode());
	}
	@Test
	public void postTest() {
		RestAssured.useRelaxedHTTPSValidation();
		JSONObject userObj = new JSONObject();
		userObj.put("name", "morpheous");
		userObj.put("job", "leader");
		RestAssured.baseURI ="https://reqres.in/api";
		given()
		.header("ContentType", 85)
		.contentType(ContentType.JSON)
		.body(userObj.toJSONString())
		.when()
		.post("/users")
		.then().assertThat()
		.statusCode(201)
		//.body("job", equalTo("leader"))
		//.body("data.email", hasItems("janet , weaver"))
		.log().all();
	}
	@Test
	public void putTest() {
		RestAssured.useRelaxedHTTPSValidation();
		JSONObject userObj = new JSONObject();
		userObj.put("name", "morpheous");
		userObj.put("psw", "leader");
		RestAssured.baseURI ="https://reqres.in/api";
		given()
		.header("ContentType", 90)
		.contentType(ContentType.JSON)
		.body(userObj.toJSONString())
		.when()
		.put("/users/2")
		.then().assertThat()
		.statusCode(200)
		//.body("job", equalTo("leader"))
		//.body("data.email", hasItems("janet , weaver"))
		.log().all();
	}
	@Test
	public void patchTest() {
		RestAssured.useRelaxedHTTPSValidation();
		JSONObject userObj = new JSONObject();
		userObj.put("name", "morph");
		userObj.put("job", "leader");
		RestAssured.baseURI ="https://reqres.in/api";
		given()
		.header("ContentType", 90)
		.contentType(ContentType.JSON)
		.body(userObj.toJSONString())
		.when()
		.patch("/users/2")
		.then().assertThat()
		.statusCode(200)
		//.body("job", equalTo("leader"))
		//.body("data.email", hasItems("janet , weaver"))
		.log().all();
		System.out.println(userObj);
	}
	@Test
	public void deleteAnUser() {
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.baseURI ="https://reqres.in/api";
		given()
			.when()
				.delete("/api/users/2")
				.then()
				.assertThat()
				.statusCode(204).and()
				.time(lessThan(2000l));
	}
	
}
