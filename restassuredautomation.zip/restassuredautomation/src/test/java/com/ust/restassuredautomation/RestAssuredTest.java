package com.ust.restassuredautomation;
import static io.restassured.RestAssured.given;
import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.equalTo;

import org.json.simple.JSONObject;

public class RestAssuredTest {
@Test
	public void test() {
		RestAssured.useRelaxedHTTPSValidation();
		Response res = RestAssured.get("https://reqres.in/api/users?page=2");//RestAssured & Response are a class
		//Response res = get("https://reqres.in/api/users?page=2");
		System.out.println(res.getStatusCode());
		System.out.println(res.getTime());
		System.out.println(res.getStatusLine());
		System.out.println(res.getHeader("content-type"));
		System.out.println(res.getBody());
		System.out.println(res.getBody().asString());
		int statusCode =res.getStatusCode();
		Assert.assertEquals(statusCode, 200);
}
@Test
	public void gettest() {
	RestAssured.baseURI="https://reqres.in/api";
	given().get("/users?page=2")
	.then().statusCode(200)
	.body("data[0].first_name" , equalTo("Michael"))
	.log().all();
}

@Test
public void posttest() {
	RestAssured.useRelaxedHTTPSValidation();
	JSONObject userObj = new JSONObject();
	userObj.put("name", "Sam");
	userObj.put("job", "Lead");
	RestAssured.baseURI ="https://reqres.in/api";
	given()
	.header("Content-Length", 85)
	.post("/users")
	.then().assertThat()
	.statusCode(201)
	.body("data.id", equalTo(374))
	//.body("data.email", hasItems("janet , weaver"))
	.log().all();
}
@Test
public void puttest() {
	RestAssured.useRelaxedHTTPSValidation();
	JSONObject userObj = new JSONObject();
	userObj.put("name", "Sam");
	userObj.put("job", "Lead");
	RestAssured.baseURI="https://reqres.in/api/users/2";
	given()
	.header("Content-Length", 85)
	.contentType(ContentType.JSON)
	.put("/users/2")
	.then().assertThat()
	.statusCode(200)
	.body("data.id", equalTo(374))
	//.body("data.email", hasItems("janet , weaver"))
	.log().all();

}
}

