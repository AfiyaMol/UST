package com.ust.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BankManagerLogin {
WebDriver driver;
	
	public BankManagerLogin(WebDriver driver){
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath ="(//button[@class='btn btn-primary btn-lg'])[2]")
	WebElement banklog;
	@FindBy(xpath="//div[2]/div/div[1]/button[3]")
	WebElement cust;
	
	@FindBy(xpath="//form/div/div/input")
	WebElement search;
	@FindBy(xpath="//table/tbody/tr/td[1]")
	WebElement text;
	
	public void manager() {
		banklog.click();
	}
	public void customers() {
		cust.click();
	}
	public void searchbar(String name) {
		search.sendKeys(name);
	}
	public String nameverify() {
		return text.getText();
	}

}

