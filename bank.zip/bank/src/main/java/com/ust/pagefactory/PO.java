package com.ust.pagefactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PO{
WebDriver driver;
	
	public PO(WebDriver driver){
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath ="(//button[@class='btn btn-primary btn-lg'])[1]")
	WebElement cusLog;
	@FindBy(id="userSelect")
	WebElement username;
	@FindBy(xpath="(//button[@class='btn btn-default'])")
	WebElement logbutton;
	@FindBy(css="body > div > div > div.ng-scope > div > div:nth-child(1) > strong")
	WebElement msg;
	
	public String title() {
		return driver.getTitle();
	}
	public void login() {
		cusLog.click();
	}
	public void user(String name) {
		Select user = new Select(username);
		user.selectByVisibleText(name);
	}
	
	public void loginbutton()  {
		logbutton.click();
		
	}	
		public String welmsg() {
			return msg.getText();
		}
		
}
//	public void entermail(String mail) {
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
//		wait.until(d -> mailfield.isDisplayed());//WAIT UNTIL THE USER NAME FIELD SHOWS UP
//		mailfield.sendKeys(mail);//ENTERING DATA
//
//	}
//
//	
//	}
//
//	public String getalertboxmessage() {
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
//		wait.until(ExpectedConditions.alertIsPresent());//WAIT FOR ALERT POPUP
//		Alert alert = driver.switchTo().alert();
//		String alertmsg = alert.getText();//FETCHING TEXT FROM ALERT
//		alert.accept();//ACCEPTING ALERT
//		return alertmsg;

