package com.ust.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Deposit {
WebDriver driver;
	
	public Deposit(WebDriver driver){
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath  ="/html/body/div/div/div[2]/div/div[3]/button[2]")
	WebElement depbutton;
	@FindBy(css="body > div > div > div.ng-scope > div > div.container-fluid.mainBox.ng-scope > div > form > div > input")
	WebElement amount;
	@FindBy(xpath="(//button[@class='btn btn-default'])")
	WebElement depositbutton;
	@FindBy(css="body > div > div > div.ng-scope > div > div.container-fluid.mainBox.ng-scope > div > span")
	WebElement msg;
	
	public String title() {
		return driver.getTitle();
	}
	public void deposit() {
		depbutton.click();
	}
	public void depamount(String number) {
		amount.sendKeys(number);
	}
	
	public void depbutton()  {
		depositbutton.click();
		
	}	
		public String succmsg() {
			return msg.getText();
		}
		

}
