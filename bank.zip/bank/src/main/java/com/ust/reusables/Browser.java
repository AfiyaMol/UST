package com.ust.reusables;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.ust.driverimplementatiom.DriverConfig;
import com.ust.utilities.ObjectConfig;
//browser and screenshot
public class Browser {
	
	public static WebDriver driver;
	public static Properties prop;
	public Browser() {
		prop = ObjectConfig.initProperties();
	}	
	public static WebDriver invokeBrowser(String browser) {
		//browser=prop.getProperty("browserName");
		try {
			if(browser.equalsIgnoreCase("chrome")) {
				driver= DriverConfig.getChromeDriver();
				
			}else if(browser.equalsIgnoreCase("msedge")) {
				driver= DriverConfig.getMSEdgeDriver();
			}
			else {
			throw new Exception ("Invalid browser name provided in property file");
		}
			}
			catch(Exception e) {
			e.getMessage();
		}
		return driver;
	}
	//method to capture Screenshot
	public static void takeScreenshot(String filepath){
		TakesScreenshot takeScreenshot =(TakesScreenshot) driver;
			File srcFile = takeScreenshot.getScreenshotAs(OutputType.FILE);
			File destFile = new File(filepath); 
			try {
				FileUtils.copyFile(srcFile, destFile);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
	public static String getTimeStamp() {
		return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		
		
	}
	public static void wait(int seconds) {
		try {
			Thread.sleep(seconds);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}