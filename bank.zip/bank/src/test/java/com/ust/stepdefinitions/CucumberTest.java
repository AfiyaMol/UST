package com.ust.stepdefinitions;

import static org.testng.Assert.assertTrue;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

import com.ust.pagefactory.BankManagerLogin;
import com.ust.pagefactory.PO;
import com.ust.reusables.Browser;
import com.ust.utilities.ObjectConfig;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CucumberTest {
	WebDriver driver = Hooks.driver;
	Properties properties = Hooks.properties;
	PO p;
	BankManagerLogin bm;
	
	@Given("I am on home page")
	public void i_am_on_home_page() {
	    driver.get(ObjectConfig.initProperties().getProperty("url"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		bm= new BankManagerLogin(driver);
	}

	@When("I click bank manager login")
	public void i_click_bank_manager_login() {
	    bm.manager();
	    Browser.wait(3000);
	}

	@When("I select customers icon")
	public void i_select_customers_icon() {
		Browser.wait(3000);
	   bm.customers();
	}

	@When("I search for a  {string}")
	public void i_search_for_a(String string) {
		Browser.wait(3000);
	    bm.searchbar(string);
	}

	@Then("Data with {string} name is displayed")
	public void data_with_name_is_displayed(String custName) {
	   assertTrue(bm.nameverify().contains(custName));
	}

	


}
