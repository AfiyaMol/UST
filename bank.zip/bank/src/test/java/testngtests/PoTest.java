package testngtests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ust.pagefactory.PO;
import com.ust.reusables.Browser;
import com.ust.utilities.ExcelReader;
import com.ust.utilities.ObjectConfig;
//@Listeners(ExtentReportsListener.class)
public class PoTest {
		WebDriver driver;
		PO p;
		Properties prop;
		@BeforeMethod
		public void setUp() {            
	        //to get the data from object.properties file
			prop = ObjectConfig.initProperties();
			driver = Browser.invokeBrowser(prop.getProperty("browser"));
			driver.get(ObjectConfig.initProperties().getProperty("url"));
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
		}
		@AfterMethod
		public void tearDown() {
			driver.close();
		}
		
		@Test(dataProvider = "dp" , priority = 1)
		public void loginXYZ(String uname) {
			p= new PO(driver);
			Browser.wait(5000);
			p.login();
			Browser.wait(5000);
//			}
//		
//			public void uname(String uname) {
//			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
//			wait.until(d -> uname.isDisplayed());
			Browser.wait(5000);
			p.user(uname);
			Browser.wait(5000);
			p.loginbutton();
			System.out.println();
			assertTrue(p.welmsg().contains("Welcome"));
		}
		
		
		@DataProvider
		public String[][] dp() throws IOException {
			String path = "C:\\Users\\272317\\JavaProject\\bank\\src\\test\\resources\\datasource\\ExcelData.xlsx";
			String sheetName = "Sheet1";
			String data[][] = ExcelReader.getData(path, sheetName);
	//   System.out.println(data[0][0]);
	//   System.out.println(data[0][1]);
			return data;
		}
}
