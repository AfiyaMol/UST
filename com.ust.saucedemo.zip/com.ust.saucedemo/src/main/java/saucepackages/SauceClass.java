package saucepackages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SauceClass {
WebDriver driver;
	
	public SauceClass(WebDriver driver) {
		this.driver = driver;
	}
	
	public String login(String uname, String pwd) throws InterruptedException {
		
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.findElement(By.cssSelector("input#user-name")).clear();
		driver.findElement(By.cssSelector("input#user-name")).sendKeys(uname);
		driver.findElement(By.cssSelector("input#password")).clear();
		driver.findElement(By.cssSelector("input#password")).sendKeys(pwd);
		driver.findElement(By.cssSelector("input#login-button")).click();
		
		try {
			driver.switchTo().alert().accept();
		}
		catch(Exception e) {
			System.out.println("Alert not found!");
		}
		
		try {
			driver.findElement(By.cssSelector("button#react-burger-menu-btn")).click();		
		}
		catch (Exception e) {
			System.out.println("Username: " + uname + " Password: " + pwd + " FAILED!");
			return e.getMessage();
		}
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("a#logout_sidebar_link")));
		String logout = driver.findElement(By.cssSelector("a#logout_sidebar_link")).getText();
		driver.findElement(By.cssSelector("a#logout_sidebar_link")).click();
		return logout;
		
	}
}
