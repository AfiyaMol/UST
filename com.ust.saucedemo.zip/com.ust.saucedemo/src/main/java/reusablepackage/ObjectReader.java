package reusablepackage;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ObjectReader {
	
		Properties objpro;
		
		public ObjectReader() throws IOException
			{
				String path = "C:\\Users\\272317\\JavaProject\\com.ust.saucedemo\\objectRepo\\object.properties";
				FileReader reader=new FileReader(path);
						
				objpro=new Properties();
				objpro.load(reader);
			}
					
		public String get_BaseURL()
			{
			 	return objpro.getProperty("BaseUrl");
			}	
}
