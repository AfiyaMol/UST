package reusablepackage;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

public class ScreenshotSauceDemo {
	
	private int sNumber = 0;
	public void takeScreenshot(WebDriver driver, ExtentTest test, String mName){
		File sFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File dest = new File("Screenshots/screenshot(" + mName + " " + sNumber + ").png"); 
		try {
			FileUtils.copyFile(sFile, dest);
		} catch (IOException e) {
			System.out.println("Screenshot class: IOException" + e.getMessage());
		}
		test.addScreenCaptureFromPath("../Screenshots/screenshot(" + mName + " " + sNumber + ").png"); 
		sNumber++;
	}
}
