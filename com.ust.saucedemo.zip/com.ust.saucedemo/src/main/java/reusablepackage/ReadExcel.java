package reusablepackage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
	
	XSSFWorkbook wb;
	XSSFSheet sh;
	
	public ReadExcel() throws IOException{
		String s="C:\\Users\\272317\\JavaProject\\com.ust.saucedemo\\datasource\\datasetSaucedemo.xlsx";
		FileInputStream fis;
		
		try
		{
			fis = new FileInputStream(s);
			wb = new XSSFWorkbook(fis);
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	public String getData(int sheetnumber, int row, int col)
	{
		sh = wb.getSheetAt(sheetnumber);
		String data = sh.getRow(row).getCell(col).getStringCellValue();
		return data;
		
	}
	public int getRowCount(int sheetNumber)
	{
		int rowCount = wb.getSheetAt(sheetNumber).getLastRowNum();
		System.out.println("Total number of rows available in Excel sheet..."+rowCount);
		return rowCount;
	}
	
	public Object[][] getAllData(int sheetNumber) {
		int rowCount =getRowCount(sheetNumber) + 1;
      Object[][] obj = new Object[rowCount][];
      for (int i = 0; i < rowCount; i++) {
          obj[i] = new Object[] {getData(0, i, 0), getData(0, i, 1)};
      }
      return obj;	
}
}



