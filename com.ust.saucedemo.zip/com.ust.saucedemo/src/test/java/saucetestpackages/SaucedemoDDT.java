package saucetestpackages;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import reusablepackage.ObjectReader;
import reusablepackage.ReadExcel;
import reusablepackage.ScreenshotSauceDemo;
import reusablepackages.Browser;
import saucepackages.SauceClass;

public class SaucedemoDDT {
	
	WebDriver driver;
	Browser br;
	ObjectReader or;
	SauceClass sp;
	ScreenshotSauceDemo sc;
	ExtentReports extent;
	ExtentSparkReporter spark;
	ReadExcel excel;

	public static final String PATH = System.getProperty("user.dir") + "\\DataSource\\DataSet.xlsx";

	@BeforeClass
	public void setup() { 

		br = new Browser();
		driver = br.launch_Chrome();
		sp = new SauceClass(driver);
		sc = new ScreenshotSauceDemo();
		try {
			or = new ObjectReader();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		try {
			excel = new ReadExcel();
		} catch (IOException e) {
			
			e.printStackTrace();
		}

		driver.get(or.get_BaseURL());
		driver.manage().window().maximize();

		extent = new ExtentReports();
		spark = new ExtentSparkReporter("Reports/SwagLabs.html");
		extent.attachReporter(spark);

	}

	@Test (priority = 0, dataProvider = "dp")
	public void verifyLogin(String uname, String password) throws InterruptedException {

		String expectedResult = "Logout";
		String actualResult = sp.login(uname, password);

		System.out.println(uname + " " + actualResult);
		
		assertEquals(actualResult, expectedResult);

		 try {

			assertEquals(actualResult, expectedResult);

		}
		catch(AssertionError e) {
			
			throw e;
		} 
	}

	@AfterMethod
	public void checkStatus(ITestResult result) {

		String methodName = result.getMethod().getMethodName();
		ExtentTest test = extent.createTest("Test case " + methodName);

		try {

			if(result.getStatus() == ITestResult.SUCCESS) {

				

				test.log(Status.PASS, "Test case passed."); 
				test.assignAuthor("AFIYA").assignDevice("Windows"); 

				Reporter.log(methodName + " test case passed.");
			}
			else if(result.getStatus() == ITestResult.FAILURE) {

				

				test.log(Status.FAIL, "Test case failed."); 
				test.assignAuthor("AFIYA").assignDevice("Windows"); 

				Reporter.log(methodName + " test case failed.");

				sc.takeScreenshot(driver, test, methodName); 
			}
		}
		catch(Exception e) {

			System.out.println(e.getMessage());
		}
	}
	@AfterClass
	public void tearDown() {

		extent.flush();
		driver.quit();

	}

	@DataProvider (name ="dp")
	public Object[][] dp() {

		int rowCount = excel.getRowCount(0) + 1;
		System.out.println("Total number of rows: " + rowCount);

		// Initialize an object array with the size of rows of Excel sheet
		Object[][] obj = new Object[rowCount][];

		for(int i = 0; i < rowCount; i++) {

			// Create a new object with username and password taken from Excel and add it to the i'th index
			obj[i] = new Object[] {excel.getData(0, i, 0), excel.getData(0, 0, 1)};

		}

		return obj;
	} }
