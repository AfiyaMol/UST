package com.ust.restassured;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class PutUpdate {
	public static void updateUser() {
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.baseURI="https://reqres.in/";
		given().log().all().body("{\n"
				+ "    \"name\": \"morpheus\",\n"
				+ "    \"job\": \"zion resident\"\n"
				+ "}")
		.when().put("/api/users")
		.then().log().all().assertThat().statusCode(200)
		.body("job",equalTo("zion resident"));
		}

	
	 public static String payloadparams(String name, String job) {
	        return "{\r\n"
	                + "    \"name\": \"" + name + "\",\r\n"
	                + "    \"job\": \"" + job + "\"\r\n"
	                + "}\r\n";
	    }
}
