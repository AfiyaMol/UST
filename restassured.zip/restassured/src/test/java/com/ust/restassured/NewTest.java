package com.ust.restassured;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class NewTest {
	@Test(dataProvider = "getData")
	  public void f(String name, String job) {
			ReqresAPI.createUserDataDriven(name,job);
		 
	  }
	  @DataProvider
	  public Object[][] getData(){
			Object[][] data = new Object[3][2];
			data[0][0] =" Afiya";
			data[0][1]="Tester";
			
			data[1][0] =" Basi";
			data[1][1]="HR";
			
			data[2][0] =" Shuhaib";
			data[2][1]="Manager";
			return data;
		}
}
