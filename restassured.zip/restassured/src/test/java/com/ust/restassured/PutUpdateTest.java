package com.ust.restassured;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class PutUpdateTest {
	@Test(dataProvider = "putData")
	  public void f(String name, String job) {
			PutUpdate.payloadparams(name, job);
		 
	  }
	  @DataProvider
	  public Object[][] putData(){
			Object[][] data = new Object[1][2];
			data[0][0] =" Afiya";
			data[0][1]="Tester";
			
			return data;
		}
}
