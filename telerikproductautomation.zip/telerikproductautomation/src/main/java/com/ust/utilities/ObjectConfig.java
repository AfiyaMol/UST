package com.ust.utilities;

import java.io.FileInputStream;
import java.util.Properties;

public class ObjectConfig {
	private static Properties prop;
	public static Properties initProperties()
	{	
		if(prop == null) {
		prop = new Properties();
		try {
			FileInputStream file = new FileInputStream(System.getProperty("C:\\Users\\272317\\JavaProject\\telerikproductautomation\\src\\test\\resources\\objectrepository\\object.properties"));
		//	C:\Users\272317\JavaProject\telerikproductautomation\src\test\resources\objectrepository\object.properties
			prop.load(file);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	return prop;
}
}