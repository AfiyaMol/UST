package com.ust.utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.ust.reusables.Browser;

public class ExtentManager {

	public static ExtentReports extent;
	public static ExtentSparkReporter htmlReporter;
	
	public static ExtentReports createInstance(){
	
			String repname="TestReport-" + Browser.getTimeStamp()+".html";
			htmlReporter= new ExtentSparkReporter(System.getProperty("user.dir") + "//Reports//" +repname);
//			.viewConfigurer()
//			.viewOrder
//			.as
			
			htmlReporter.config().setDocumentTitle("Extent report demo");
			htmlReporter.config().setReportName("test report");
			htmlReporter.config().setTimelineEnabled(true);
			htmlReporter.config().setTheme(Theme.DARK);
			htmlReporter.config().setTimeStampFormat("MM/dd/yyyy HH:mm:ss");
			
			extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			extent.setSystemInfo("OS", "Windows");
			extent.setSystemInfo("HOST NAME", "LOCAL HOST");
			extent.setSystemInfo("ENVIRONMENT", "QA");
			extent.setSystemInfo("USER NAME", "Aafiya");
			
			return extent;
			
	}

	}

