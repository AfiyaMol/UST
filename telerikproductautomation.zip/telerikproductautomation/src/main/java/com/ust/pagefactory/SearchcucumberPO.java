package com.ust.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchcucumberPO {

	WebDriver driver;
	 
	public SearchcucumberPO(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(css = "#js-tlrk-nav > section > div > div.TK-Aside.TK--Mobile > ul > li.TK-Aside-Menu-Item.TK-Aside-Menu-Button--Search > a > svg")
	WebElement searchicon;
	@FindBy(xpath  = "//tk-site-search/div/div/input")
	WebElement type;
	@FindBy(className = "TK-Tag-Input-Button")
	WebElement searchbutton;
	@FindBy(xpath = "//div[@id='js-results-wrapper']/div[1]/div")
	WebElement result;
	
	

	public void searchIcon() {
		searchicon.click();
	}
	public void course(String name) {
		type.sendKeys(name);
	}
	public void searchbar() {
		searchbutton.click();
	}
	public String results() {
		 return result.getText();
	}
}


