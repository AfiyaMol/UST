package com.ust.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.reusables.Browser;

public class LoginPO {
	WebDriver driver;
	 
	public LoginPO(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath =  "//ul[2]/li[5]/a ")
	WebElement trial;
	
	@FindBy(css = "#ContentPlaceholder1_C423_Col00 > a")
	WebElement trynow;
			
	@FindBy(xpath = "//header/div[1]/div/div[1]/h1")
	WebElement text;
	
	
	public void trialLink() {
		trial.click();
	}
	public void tryNow() {
		trynow.click();
	}
	public String success() {
		return text.getText();
	}
	public String title() {
		return driver.getTitle();
	}
	public String url() {
		return driver.getCurrentUrl();
	}
	public void email(String e) {
		
	}
	public void pswd(String p) {
		
	}
}
