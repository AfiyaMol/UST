package com.ust.pagefactory;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.reusables.Browser;

public class BuyProductPO {
	WebDriver driver;
	 
	public BuyProductPO(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	@FindBy(xpath= "//buton[@id='onetrust-accept-btn-handler']")
	WebElement accept;
	@FindBy(linkText = "See Plans & Pricing ")
	WebElement seeplan;
	@FindBy(linkText = "Buy now")
	WebElement buynow;
	@FindBy(xpath = "//div/div[5]/button/span[2]")
	WebElement contasguest;
	@FindBy(id = "biFirstName ")
	WebElement fname;
	@FindBy(id = "biLastName")
	WebElement lname;
	@FindBy(id = "biEmail ")
	WebElement email;
	@FindBy(id = "biCompany ")
	WebElement comp;
	@FindBy(id = "biPhone ")
	WebElement phNo;
	@FindBy(id = "biAddress ")
	WebElement add;
	@FindBy(xpath =  "(//input[@id='k-84d28a24-4ed9-44bf-8f15-d6af40759424']) ")
	WebElement country;
	@FindBy(id = "biCity ")
	WebElement city;
	@FindBy(id = "biZipCode ")
	WebElement zip;
	@FindBy(xpath ="//button[@class='btn btn-primary e2e-continue sm-width-100 loader-button'] ")
	WebElement cont;
	@FindBy(id = "licenseAgreementCheck ")
	WebElement terms;
	@FindBy(xpath = "//div/div/div/form ")
	WebElement contpayment;
	@FindBy(xpath = "//div[3]/div[1]/h2")
	WebElement yourorder;
	
	
	public void allow() {
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
//		wait.until(d -> accept.isDisplayed());
		Browser.wait(1000);
		driver.switchTo().alert().accept();
		
		//accept.click();
	}
	public void seeplans() {
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
//		wait.until(d -> seeplan.isDisplayed());//WAIT UNTIL THE USER NAME FIELD SHOWS UP
		seeplan.click();
	}
	
	public void buyNow() {
		buynow.click();
	}
	public void guest() {
		contasguest.click();
	}
	public void firstname(String name) {
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
//		wait.until(d -> fname.isDisplayed());//WAIT UNTIL THE USER NAME FIELD SHOWS UP
		fname.sendKeys(name);//ENTERING DATA
		
	}
	public void lastname(String laname) {
		lname.sendKeys();
	}
	public void email(String em) {
		email.sendKeys();
	}
	public void company(String com) {
		comp.sendKeys();
	}
	public void phonenum(String ph) {
		phNo.sendKeys();
	}
	public void address(String address) {	
		add.sendKeys();
	}
	public void country(String count) {
		country.sendKeys();
	}
	public void city(String cityname) {
		city.sendKeys();
	}
	public void zipcode(String zipcode) {
		zip.sendKeys();
	}
	public void continuebutton() {
		cont.click();
	}
	public void chechbox() {
		terms.click();
	}
	public void payment() {
		contpayment.click();
	}
	public String yourOrder() {
		 return yourorder.getText();
	}
	
	
}
