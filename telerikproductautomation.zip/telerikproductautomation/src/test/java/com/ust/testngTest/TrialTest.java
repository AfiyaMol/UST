package com.ust.testngTest;

import static org.testng.Assert.assertTrue;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.pagefactory.LoginPO;
import com.ust.reusables.Browser;
import com.ust.utilities.ExtentReportsListener;
import com.ust.utilities.ObjectConfig;


@Listeners(ExtentReportsListener.class)
public class TrialTest {
	WebDriver driver;
	
	Properties prop;
	LoginPO log;
	
	@BeforeClass
	public void setUp() {            
        //to get the data from object.properties file
		prop = ObjectConfig.initProperties();
		driver = Browser.invokeBrowser(prop.getProperty("browser"));
		driver.get(ObjectConfig.initProperties().getProperty("url"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
		log = new LoginPO(driver);
	}
	@AfterClass
	public void tearDown() {
		driver.close();
	}
	@Test(priority = 1)
	public void verifyTitle() {
		
		Browser.wait(1000);
		log.title();
	}
	@Test(priority = 0)
	public void verifyUrl() {
		Browser.wait(1000);
		
		log.url();
	}
	@Test(priority = 2)
	public void verifyTrial() {
		Browser.wait(1000);
		
		log.trialLink();
		log.tryNow();
		
		//String email, String pswd
		assertTrue(log.success().contains("Thank You"));
	}
}
