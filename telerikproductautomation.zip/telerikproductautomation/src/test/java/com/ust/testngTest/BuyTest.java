package com.ust.testngTest;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.pagefactory.BuyProductPO;
import com.ust.reusables.Browser;
import com.ust.utilities.ExcelReader;
import com.ust.utilities.ExtentReportsListener;
import com.ust.utilities.ObjectConfig;

@Listeners(ExtentReportsListener.class)
public class BuyTest {
		WebDriver driver;
		BuyProductPO bp;
		Properties prop;
		@BeforeMethod
		public void setUp() {            
	        //to get the data from object.properties file
			prop = ObjectConfig.initProperties();
			driver = Browser.invokeBrowser(prop.getProperty("browser"));
			Browser.wait(5000);
			driver.get(ObjectConfig.initProperties().getProperty("url"));
			Browser.wait(5000);
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));
		}
//		@AfterMethod
//		public void tearDown() {
//			driver.close();
//		}
		
		@Test(dataProvider = "dp" )
		public void productPurchase(String fname, String lname,String email, String compname , String phno, String add, String country, String city, String zipcode) {
			bp= new BuyProductPO(driver);
			bp.allow();
		//	Browser.wait();
			bp.seeplans();
			Browser.wait(5000);
			
			
			bp.buyNow();
			Browser.wait(5000);
			bp.guest();
			Browser.wait(5000);
		
			bp.firstname(fname);
			Browser.wait(5000);
			bp.lastname(lname);
			bp.email(email);
			bp.company(compname);
			bp.phonenum(phno);
			bp.address(add);
			bp.country(country);
			bp.city(city);
			bp.zipcode(zipcode);
			bp.continuebutton();
			bp.chechbox();
			bp.payment();
			Browser.wait(5000);
			assertTrue(bp.yourOrder().contains("Your order"));
		}
		
		
		@DataProvider
		public String[][] dp() throws IOException {
			String path = "C:\\Users\\272317\\JavaProject\\telerikproductautomation\\src\\test\\resources\\datasource\\ExcelData.xlsx";
			String sheetName = "Sheet1";
			String data[][] = ExcelReader.getData(path, sheetName);
			return data;
		}
}
