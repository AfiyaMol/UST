package com.ust.stepdefinitionss;

import static org.testng.Assert.assertTrue;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;


import com.ust.pagefactory.SearchcucumberPO;
import com.ust.reusables.Browser;
import com.ust.utilities.ObjectConfig;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class TelerikcucumberTest {
	
	WebDriver driver = Hooks.driver;
	Properties properties = Hooks.properties;
	SearchcucumberPO sc;
	
	
	@Given("I am in home page")
	public void i_am_in_home_page() {
		 driver.get(ObjectConfig.initProperties().getProperty("url"));
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
			sc= new SearchcucumberPO(driver);
	}

	@And("I clicked search icon")
	public void i_clicked_search_icon() {
		Browser.wait(3000);
	    sc.searchIcon();
	}

	@When("I search for a product")
	public void i_search_for_a_product() {
		Browser.wait(3000);
	    sc.course(properties.getProperty("prod"));
	}

	@When("search bar is clicked")
	public void search_bar_is_clicked() {
		Browser.wait(3000);
	    sc.searchbar();
	}

	@Then("I validate the outcomes")
	public void i_validate_the_outcomes() {
	    assertTrue(sc.results().contains("results"));
	}

}
