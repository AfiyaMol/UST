package com.ust.runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		features = {"C:\\Users\\272317\\JavaProject\\telerikproductautomation\\src\\test\\resources\\features\\telerik.feature"},
		glue = {"com.ust.stepdefinitionss"},
		//tags= "@addtocart",
//		publish = true,
			plugin = {"me.jvt.cucumber.report.PrettyReports:Reports"}
//		plugin = { "pretty",
//		"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:","timeline:test-output-thread","html:Reports/cucumber-reports/index.html"}

		)
public class CucumberRunner extends AbstractTestNGCucumberTests{

}
