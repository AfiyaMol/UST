$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"b689bec5-f05c-4b5e-b125-9ce868ca7efa","feature":"Search feature of telerik","scenario":"Searching for product","start":1717066298139,"group":1,"content":"","tags":"@tag,@smoke,","end":1717066298295,"className":"failed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});