package com.ust.nopcommerceutils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {

	XSSFWorkbook wb;
	XSSFSheet sh;
	
	public ExcelReader() throws IOException{
		String s="C:\\Users\\272317\\JavaProject\\nopcommerce\\DataSource\\datasetnc.xlsx";
		FileInputStream fis;
		
		try
		{
			fis = new FileInputStream(s);
			wb = new XSSFWorkbook(fis);
		}
		catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	public String getData(int sheetnumber, int row, int col)
	{
		sh = wb.getSheetAt(sheetnumber);
		String data = sh.getRow(row).getCell(col).getStringCellValue();
		return data;
		
	}
	public int getRowCount(int sheetNumber)
	{
		int rowCount = wb.getSheetAt(sheetNumber).getLastRowNum();
		System.out.println("Total number of rows available in Excel sheet..."+rowCount);
		return rowCount;
	}
	
	public Object[][] getAllData(int sheetNumber) {
		int rowCount =getRowCount(sheetNumber) + 1;
      Object[][] obj = new Object[rowCount][];
      for (int i = 0; i < rowCount; i++) {
          obj[i] = new Object[] {getData(0, i, 0), getData(0, i, 1)};
      }
      return obj;	
}
}


//XSSFWorkbook workbook;
//XSSFSheet sheet;
//
//public ExcelReader(String filepath) {
//	FileInputStream fis;
//	try {
//
//		fis = new FileInputStream(filepath);
//
//		try {
//
//			workbook = new XSSFWorkbook(fis);
//		}
//		catch(IOException e) {
//
//			System.out.println("IOException!!!");
//			e.printStackTrace();
//		}
//	}
//	catch(FileNotFoundException e) {
//
//		System.out.println("File Not Found!!!\n");
//		e.printStackTrace();
//	}
//}
//
//public String getData(int sheetNumber, int row, int col) {
//	
//	try {
//		sheet = workbook.getSheetAt(sheetNumber);
//		String data = sheet.getRow(row).getCell(col).getStringCellValue();
//		return data;
//	}
//	catch(Exception e) {
//		e.printStackTrace();
//	}
//	
//	return null;
//
//}
//
//public int getRowCount(int sheetNumber) {
//
//	sheet = workbook.getSheetAt(sheetNumber);
//	int totalRows = sheet.getLastRowNum();
//	//System.out.println("Total number of rows: " + totalRows);
//	return totalRows + 1; // Because index starts from zero in an excel sheet
//}
