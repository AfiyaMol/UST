package com.ust.nopcommerceutils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

public class Screenshot {
	private int ssNumber = 0;
	public void takeScreenshot(WebDriver driver, ExtentTest test, String methodName){
		File sFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File dest = new File("ScreenshotNC/screenshot(" + methodName + " " + ssNumber + ").png"); 
		try {
			FileUtils.copyFile(sFile, dest);
		} catch (IOException e) {
			System.out.println("Screenshot class: IOException" + e.getMessage());
		}
		test.addScreenCaptureFromPath("../ScreenshotNC/screenshot(" + methodName + " " + ssNumber + ").png"); 
		ssNumber++;
	}
}
