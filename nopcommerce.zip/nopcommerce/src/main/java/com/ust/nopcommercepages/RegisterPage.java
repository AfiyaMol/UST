package com.ust.nopcommercepages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class RegisterPage {
	WebDriver driver;
	
	
	 public RegisterPage(WebDriver driver) {
		this.driver=driver;
		
	}
	By reg=By.linkText("Register");
	By id=By.id("gender-female");
	By fname=By.id("FirstName");
	By lname=By.id("LastName");
	By day=By.name("DateOfBirthDay");
	By month=By.name("DateOfBirthMonth");
	By year=By.name("DateOfBirthYear");
	By email=By.xpath("(//input[@id='Email'])");
	By company= By.id("Company");
	By pswd= By.id("Password");
	By cpswd=By.id("ConfirmPassword");
	By regButton =By.id("register-button");
	By msg=By.xpath("(//div[@class='result'])");
	
	
	public String getTitle() {
		String title=driver.getTitle();
				return title;
	}
	
	public String register() {
		driver.findElement(reg).click();
		driver.findElement(id).click();
		driver.findElement(fname).sendKeys("Afiya");
		driver.findElement(lname).sendKeys("Mol");
		Select dayB = new Select(driver.findElement(day));
		dayB.selectByVisibleText("25");
		Select monthB = new Select(driver.findElement(month));
		monthB.selectByVisibleText("February");
		Select yearB = new Select(driver.findElement(year));
		yearB.selectByVisibleText("2000");
		driver.findElement(email).sendKeys("afiyyysa@ust.com");
		driver.findElement(company).sendKeys("UST");
		driver.findElement(pswd).sendKeys("Afiya@123");
		driver.findElement(cpswd).sendKeys("Afiya@123");
		driver.findElement(regButton).click();
		 String expmsg="Your registration completed";
		 String actmsg=driver.findElement(msg).getText();
		 //System.out.println(actmsg);
		
		return actmsg;
		
	}

}
