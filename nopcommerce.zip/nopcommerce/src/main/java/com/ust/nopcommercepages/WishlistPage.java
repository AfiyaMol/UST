package com.ust.nopcommercepages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class WishlistPage {
	WebDriver driver;
	
	
	 public WishlistPage(WebDriver driver) {
		this.driver=driver;
		
	}
	 By wl=By.linkText("Wishlist");
	// By add= By.name("addtocartbutton");
	 
	 By wmsg=By.xpath("//*[@id=\"main\"]/div/div/div/div[2]/div");
	 
	 public String wishlist() {
		 driver.findElement(wl).click();
		// driver.findElement(add).click();
		 String expmsg="Your registration completed";
		 String actmsg=driver.findElement(wmsg).getText();
		return actmsg;
		 
	 }
}
