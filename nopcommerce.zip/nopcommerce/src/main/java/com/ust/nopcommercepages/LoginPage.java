package com.ust.nopcommercepages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
	WebDriver driver;
	
	
	 public LoginPage(WebDriver driver) {
		this.driver=driver;
		
	}
	 //login for registered user
	By login=By.linkText("Log in");
	By uname=By.className("email");
	By pswd=By.className("password");
	By loginButton=By.xpath("//div[2]/form/div[3]/button");
	//search items
	By search=By.id("small-searchterms");
	By searchButton=By.xpath("(//button[@class='button-1 search-box-button'])");
	//adding to cart
	By select = By.xpath("//div/div/div[1]/div/div[2]/div[3]/div[2]/button[1]");
	By addtocart=By.xpath("//div/div/div[1]/div/div[2]/div[3]/div[2]/button[3]");
	
	public void login() throws IOException{
		driver.findElement(login).click();
		driver.findElement(uname).clear();
		driver.findElement(uname).sendKeys("afiya@gmail.com");
		driver.findElement(pswd).clear();
		driver.findElement(pswd).sendKeys("aafiyamol");
		driver.findElement(loginButton).click();
	}
	public void landingpage() {
		driver.findElement(search).sendKeys("APPLE");
		driver.findElement(searchButton).click();
		List<WebElement> dp = driver.findElements(By.id("products-orderby"));
		for(int i = 0; i<dp.size(); i++){
		dp.get(i).click(); 
		
		}
	}
	public void addToWishlist() {
		driver.findElement(select).click();
		driver.findElement(addtocart).click();
		}
}

//afiya@gmail.com-aafiyamol