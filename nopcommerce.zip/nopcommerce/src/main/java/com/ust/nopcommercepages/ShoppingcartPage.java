package com.ust.nopcommercepages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ShoppingcartPage {
	WebDriver driver;
	
	
	 public ShoppingcartPage(WebDriver driver) {
		this.driver=driver;
		
	}
	 By sc=By.linkText("Shopping cart");
	 By search = By.xpath("//*[@id=\"small-searchterms\"]");
	 By searchB=By.xpath("//*[@id=\"small-searchterms\"]");
	 
	 
	 public void shoppingcart()
	 	{
		 driver.findElement(sc).click();
		 driver.findElement(search).sendKeys("SAMSUNG");
		 driver.findElement(searchB).click();
		 
		 
		 }
}
