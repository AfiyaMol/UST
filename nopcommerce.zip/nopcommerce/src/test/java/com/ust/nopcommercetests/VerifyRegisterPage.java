package com.ust.nopcommercetests;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.ust.nopcommercepages.LoginPage;
import com.ust.nopcommercepages.RegisterPage;
import com.ust.nopcommercepages.ShoppingcartPage;
import com.ust.nopcommercepages.WishlistPage;
import com.ust.nopcommerceutils.Browser;
import com.ust.nopcommerceutils.ExcelReader;
import com.ust.nopcommerceutils.ObjectReader;
import com.ust.nopcommerceutils.Screenshot;

public class VerifyRegisterPage {
	WebDriver driver;
	Browser br;
	ObjectReader or;
	LoginPage lp;
	RegisterPage rp;
	ShoppingcartPage sp;
	WishlistPage wp;
	Screenshot ss;
	ExtentReports extent;
	ExtentSparkReporter spark;
	ExcelReader excel;
	
	@BeforeMethod
	public void setUp() throws IOException {
		
		br = new Browser();
		driver = br.launch_Chrome();
		or = new ObjectReader();
		lp = new LoginPage(driver);
		rp = new RegisterPage(driver);
		ss = new Screenshot();
		sp = new ShoppingcartPage(driver);
		wp = new WishlistPage(driver);

		driver.get(or.get_BaseURL());
		driver.manage().window().maximize();

		extent = new ExtentReports();
		spark = new ExtentSparkReporter("Report/NopCommerce.html");
		extent.attachReporter(spark);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(6));

	}
  @Test(priority = 1)
  public void registerPage() {
	  rp.getTitle();
	  rp.register();
  }
private void AssertEquals(String expmsg, String actmsg) throws InterruptedException {
		String expectedResult = "Logout";
		String actualResult = rp.register();
		
		assertEquals(actmsg, expmsg);

		 try {

			assertEquals(actmsg, expmsg);
		}
		catch(AssertionError e) {
			throw e;
		} 
	}

	@AfterMethod
	public void checkStatus(ITestResult result) {

		String methodName = result.getMethod().getMethodName();
		ExtentTest test = extent.createTest("Test case " + methodName);

		try {

			if(result.getStatus() == ITestResult.SUCCESS) {

				

				test.log(Status.PASS, "Test case passed."); 
				test.assignAuthor("AFIYA").assignDevice("Windows"); 

				Reporter.log(methodName + " test case passed.");
			}
			else if(result.getStatus() == ITestResult.FAILURE) {

				

				test.log(Status.FAIL, "Test case failed."); 
				test.assignAuthor("AFIYA").assignDevice("Windows"); 

				Reporter.log(methodName + " test case failed.");

				ss.takeScreenshot(driver, test, methodName); 
			}
		}
		catch(Exception e) {

			System.out.println(e.getMessage());
		}
	}
	@Test(priority = 2)
	 public void loginPage() throws IOException {
		lp.login();
		lp.landingpage();
		lp.addToWishlist();
	}
	
	@Test(priority = 3)
	 public void wishlistPage() throws IOException {
		wp.wishlist();
		
	}
	private void AssertEquals1(String msg, String emsg) throws InterruptedException {
		String expectedResult = "The wishlist is empty!";
		String actualResult = wp.wishlist();
		
		assertEquals(msg, emsg);

		 try {

			assertEquals(msg, emsg);
		}
		catch(AssertionError e) {
			throw e;
		} 
	}
	
	@Test(priority = 4)
	 public void shoppingCartPage() throws IOException {
		sp.shoppingcart();
		
	}
	@AfterTest
	public void tearDown() {
		driver.quit();
		extent.flush();
	}
	}

